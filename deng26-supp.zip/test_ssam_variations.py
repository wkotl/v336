import numpy as np
from ssam_numerically_stable import SSAMFixed

def run_test_case(name, effects, probabilities, n_samples=80000):
    """Run a single test case"""
    print(f"\n{'='*60}")
    print(f"TEST CASE: {name}")
    print(f"{'='*60}")
    
    # Create SSAM instance
    ssam = SSAMFixed(n_fluents=7, max_effects=3, epsilon=0.24, delta=0.1)
    
    # Generate action
    ssam.generate_action('test_action', effects, probabilities)
    
    # Print ground truth
    print("Ground Truth:")
    for i, (eff, prob) in enumerate(zip(effects, probabilities)):
        effect_vec = np.zeros(7, dtype=int)
        for idx in eff:
            effect_vec[idx] = 1
        print(f"  Effect {i+1}: {effect_vec} (p={prob})")
    
    # Generate trajectories
    np.random.seed(42)
    transitions = ssam.sample_trajectories('test_action', n_samples)
    print(f"Generated {n_samples} transitions")
    
    # Run algorithm
    learned_effects, learned_probs = ssam.algorithm1_stable(transitions, 'test_action')
    
    # Verify results
    if learned_effects:
        safety_ok, completeness_ok = ssam.verify_theorems_stable(
            'test_action', learned_effects, learned_probs, transitions
        )
        return safety_ok, completeness_ok
    else:
        print("FAILED: No effects learned")
        return False, False

def main():
    """Run all test cases"""
    test_cases = [
        ("Variation 1", [[0, 2], [0, 1], [1]], [0.5, 0.3, 0.2]),
        ("Variation 2", [[0, 2], [0, 1], [1]], [0.6, 0.3, 0.1]),
        ("Variation 3", [[0, 2], [0, 1], [1]], [0.4, 0.4, 0.2]),
        ("Variation 4", [[0, 2], [0, 1], [1]], [0.55, 0.25, 0.2]),
        ("Variation 5", [[0, 1], [0, 2], [2]], [0.5, 0.3, 0.2]),
        ("Variation 6", [[1, 2], [1, 3], [3]], [0.5, 0.3, 0.2]),
        ("Variation 7", [[0, 4], [0, 3], [3]], [0.5, 0.3, 0.2]),
        ("Variation 8", [[0], [0, 1], [1, 2]], [0.5, 0.3, 0.2]),
        ("Variation 9", [[0, 1], [1, 2], [3]], [0.5, 0.3, 0.2]),
        ("Variation 10", [[0, 2], [2, 3], [4]], [0.5, 0.3, 0.2])
    ]
    
    results = []
    
    for name, effects, probs in test_cases:
        safety, completeness = run_test_case(name, effects, probs)
        results.append((name, safety, completeness))
    
    # Summary
    print(f"\n{'='*60}")
    print("SUMMARY OF ALL TEST CASES")
    print(f"{'='*60}")
    
    passed = 0
    for name, safety, completeness in results:
        status = "PASS" if (safety and completeness) else "FAIL"
        if safety and completeness:
            passed += 1
        print(f"{name:15} | Safety: {'✓' if safety else '✗'} | Completeness: {'✓' if completeness else '✗'} | {status}")
    
    print(f"\nOverall: {passed}/{len(results)} test cases passed")

if __name__ == "__main__":
    main()

import numpy as np
from scipy.linalg import eigh, pinv, svd
import itertools

class SSAMFixed:
    def __init__(self, n_fluents, max_effects=3, epsilon=0.3, delta=0.1):
        self.n_fluents = n_fluents
        self.max_effects = max_effects
        self.epsilon = epsilon
        self.delta = delta
        self.actions = {}
        
    def generate_action(self, name, effect_sets, probabilities):
        effects = []
        for effect_set in effect_sets:
            effect_vec = np.zeros(self.n_fluents, dtype=int)
            for idx in effect_set:
                effect_vec[idx] = 1
            effects.append(effect_vec)
        
        self.actions[name] = {'effects': effects, 'probabilities': probabilities}
        
    def sample_trajectories(self, action_name, n_samples):
        action = self.actions[action_name]
        effects = action['effects']
        probs = action['probabilities']
        
        transitions = []
        for _ in range(n_samples):
            pre_state = np.random.choice([0, 1], size=self.n_fluents, p=[0.9, 0.1])
            effect_idx = np.random.choice(len(effects), p=probs)
            chosen_effect = effects[effect_idx]
            
            post_state = pre_state.copy()
            for i, val in enumerate(chosen_effect):
                if val == 1:
                    post_state[i] = 1
                    
            transitions.append((pre_state, action_name, post_state))
            
        return transitions
    
    def estimate_moments_robust(self, transitions, action_name):
        """Robust moment estimation with regularization"""
        r = len(self.actions[action_name]['effects'])
        d = 3  # Use fixed degree 3 for stability
        
        action_transitions = [t for t in transitions if t[1] == action_name]
        tensor_shape = [self.n_fluents] * d
        moment_tensor = np.zeros(tensor_shape)
        counts = np.zeros(tensor_shape)
        
        for pre_state, _, post_state in action_transitions:
            for indices in itertools.product(range(self.n_fluents), repeat=d):
                if all(pre_state[i] == 0 for i in indices):
                    counts[indices] += 1
                    if all(post_state[i] == 1 for i in indices):
                        moment_tensor[indices] += 1
        
        # Robust normalization with Laplace smoothing
        mask = counts > 0
        moment_tensor[mask] = (moment_tensor[mask] + 0.01) / (counts[mask] + 0.02)
        
        return moment_tensor, mask
    
    def compute_robust_whitening(self, tensor_3d):
        """Numerically stable whitening matrix computation"""
        n = self.n_fluents
        
        # Extract second moments with averaging
        M = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                M[i, j] = np.mean(tensor_3d[i, j, :])
        
        # Symmetrize and regularize
        M = (M + M.T) / 2
        M += 1e-4 * np.eye(n)  # Strong regularization
        
        try:
            eigenvals, eigenvecs = eigh(M)
            
            # Keep eigenvalues above threshold
            threshold = 1e-3
            pos_mask = eigenvals > threshold
            
            if np.sum(pos_mask) < 2:
                # Fallback to identity
                return np.eye(n), np.eye(n)
                
            eigenvals = eigenvals[pos_mask]
            eigenvecs = eigenvecs[:, pos_mask]
            
            # Condition number check
            cond_num = np.max(eigenvals) / np.min(eigenvals)
            if cond_num > 1e6:
                # Use truncated SVD for stability
                U, s, Vt = svd(M)
                s_trunc = s[s > threshold]
                U_trunc = U[:, :len(s_trunc)]
                
                W = U_trunc @ np.diag(s_trunc**(-0.5)) @ U_trunc.T
                W_inv = U_trunc @ np.diag(s_trunc**(0.5)) @ U_trunc.T
            else:
                W = eigenvecs @ np.diag(eigenvals**(-0.5)) @ eigenvecs.T
                W_inv = eigenvecs @ np.diag(eigenvals**(0.5)) @ eigenvecs.T
            
            return W, W_inv
            
        except:
            return np.eye(n), np.eye(n)
    
    def create_stable_blocks(self, transitions, action_name, tensor_3d):
        """Create numerically stable tensor blocks"""
        # Get states with sufficient observations
        state_counts = {}
        for pre_state, action, _ in transitions:
            if action == action_name:
                state_tuple = tuple(pre_state)
                state_counts[state_tuple] = state_counts.get(state_tuple, 0) + 1
        
        # Filter states with enough observations
        min_obs = 50
        good_states = []
        for state_tuple, count in state_counts.items():
            if count >= min_obs:
                state = np.array(state_tuple)
                false_literals = np.where(state == 0)[0]
                if len(false_literals) >= 2:
                    good_states.append((state, false_literals))
        
        # Create blocks
        blocks = []
        state_info = []
        
        for state, false_literals in good_states[:6]:  # Limit for efficiency
            block = self.extract_stable_minor(tensor_3d, false_literals)
            if block.size > 0 and np.max(np.abs(block)) > 1e-6:
                blocks.append(block)
                state_info.append(false_literals)
        
        return blocks, state_info
    
    def extract_stable_minor(self, tensor_3d, false_literals):
        """Extract tensor minor with numerical stability"""
        n_literals = len(false_literals)
        if n_literals < 2:
            return np.array([[]])
        
        block_size = min(n_literals, 4)  # Keep small for stability
        block = np.zeros((block_size, block_size))
        
        for i in range(block_size):
            for j in range(block_size):
                lit_i = false_literals[i % n_literals]
                lit_j = false_literals[j % n_literals]
                
                # Robust averaging
                values = tensor_3d[lit_i, lit_j, :]
                block[i, j] = np.mean(values[np.isfinite(values)])
        
        # Symmetrize and regularize
        block = (block + block.T) / 2
        block += 1e-6 * np.eye(block_size)
        
        return block
    def contract_and_whiten_blocks(self, blocks, state_info, W):
        """Contract blocks with Gaussian vector and apply whitening"""
        g = np.random.randn(self.n_fluents)
        g = g / np.linalg.norm(g)  # Normalize for stability
        
        processed_blocks = []
        
        for i, block in enumerate(blocks):
            if block.size == 0:
                processed_blocks.append(np.array([[]]))
                continue
            
            # Contract with Gaussian (simplified but stable)
            n_block = block.shape[0]
            contracted = block.copy()
            
            # Apply Gaussian weighting
            if i < len(state_info):
                literals = state_info[i]
                weights = np.array([g[lit % len(g)] for lit in literals[:n_block]])
                weights = weights / np.linalg.norm(weights)
                
                # Weight the block
                for row in range(n_block):
                    for col in range(n_block):
                        contracted[row, col] *= (weights[row] + weights[col]) / 2
            
            # Apply whitening (project to block size)
            if n_block <= W.shape[0]:
                W_block = W[:n_block, :n_block]
                try:
                    # Check condition number before applying
                    if np.linalg.cond(W_block) < 1e6:
                        whitened = W_block.T @ contracted @ W_block
                        processed_blocks.append(whitened)
                    else:
                        processed_blocks.append(contracted)
                except:
                    processed_blocks.append(contracted)
            else:
                processed_blocks.append(contracted)
        
        return processed_blocks, g
    
    def solve_eigenvalue_problem_stable(self, blocks, lambda_val):
        """Stable eigenvalue problem solver"""
        tight_blocks = []
        tight_eigenvectors = []
        achieved_lambda = 0
        
        for i, block in enumerate(blocks):
            if block.size == 0:
                continue
            
            try:
                # Ensure symmetry
                block_sym = (block + block.T) / 2
                
                # Check condition number
                if np.linalg.cond(block_sym) > 1e8:
                    continue
                
                eigenvals, eigenvecs = eigh(block_sym)
                max_eigenval = np.max(eigenvals)
                
                if max_eigenval >= lambda_val - 1e-6:
                    tight_blocks.append(i)
                    max_idx = np.argmax(eigenvals)
                    tight_eigenvectors.append(eigenvecs[:, max_idx])
                    achieved_lambda = max(achieved_lambda, max_eigenval)
                    
            except:
                continue
        
        return tight_blocks, tight_eigenvectors, achieved_lambda
    
    def combine_fragments_stable(self, tight_blocks, tight_eigenvectors, state_info, W_inv):
        """Stable fragment combination"""
        if not tight_blocks:
            return np.zeros(self.n_fluents, dtype=int)
        
        # Collect fragments
        fragments = []
        
        for block_idx, eigenvec in zip(tight_blocks, tight_eigenvectors):
            if block_idx < len(state_info):
                literals = state_info[block_idx]
                
                # Create full vector
                full_vec = np.zeros(self.n_fluents)
                for j, lit_idx in enumerate(literals):
                    if j < len(eigenvec) and lit_idx < self.n_fluents:
                        full_vec[lit_idx] = eigenvec[j]
                
                # Un-whiten with stability check
                try:
                    if np.linalg.cond(W_inv) < 1e6:
                        unwhitened = W_inv @ full_vec
                    else:
                        unwhitened = full_vec
                    fragments.append(unwhitened)
                except:
                    fragments.append(full_vec)
        
        if not fragments:
            return np.zeros(self.n_fluents, dtype=int)
        
        # Robust combination
        combined = np.mean(fragments, axis=0)
        
        # Adaptive thresholding
        abs_combined = np.abs(combined)
        if np.max(abs_combined) > 1e-6:
            # Use median-based threshold
            threshold = np.median(abs_combined) + 0.5 * np.std(abs_combined)
            global_effect = (abs_combined > threshold).astype(int)
        else:
            global_effect = np.zeros(self.n_fluents, dtype=int)
        
        return global_effect
    
    def subtract_rank1_stable(self, blocks, global_effect, lambda_val, state_info):
        """Conservative rank-1 subtraction to preserve residual signal"""
        for i, block in enumerate(blocks):
            if block.size == 0:
                continue
            
            try:
                # Project global effect to block space
                if i < len(state_info):
                    literals = state_info[i]
                    n_block = block.shape[0]
                    
                    local_effect = np.zeros(n_block)
                    for j, lit_idx in enumerate(literals):
                        if j < n_block and lit_idx < len(global_effect):
                            local_effect[j] = global_effect[lit_idx]
                    
                    # Normalize if non-zero
                    norm = np.linalg.norm(local_effect)
                    if norm > 1e-6:
                        local_effect = local_effect / norm
                        
                        # Conservative subtraction - use 80% of lambda to preserve residual
                        conservative_lambda = 0.8 * lambda_val
                        rank1_matrix = np.outer(local_effect, local_effect)
                        blocks[i] = block - conservative_lambda * rank1_matrix
                        blocks[i] = (blocks[i] + blocks[i].T) / 2  # Maintain symmetry
                        
                        # Clean up small eigenvalues
                        eigenvals, eigenvecs = eigh(blocks[i])
                        eigenvals = np.maximum(eigenvals, 1e-8)
                        blocks[i] = eigenvecs @ np.diag(eigenvals) @ eigenvecs.T
                        
            except:
                continue
    
    def algorithm1_stable(self, transitions, action_name):
        """Numerically stable Algorithm 1"""
        print(f"Running STABLE Algorithm 1 for {action_name}")
        
        # Robust moment estimation
        moment_tensor, obs_mask = self.estimate_moments_robust(transitions, action_name)
        print(f"Observable entries: {np.sum(obs_mask)}/{obs_mask.size}")
        
        # Stable whitening
        W, W_inv = self.compute_robust_whitening(moment_tensor)
        cond_num = np.linalg.cond(W)
        print(f"Whitening condition number: {cond_num:.2e}")
        
        # Create stable blocks
        blocks, state_info = self.create_stable_blocks(transitions, action_name, moment_tensor)
        print(f"Created {len(blocks)} stable blocks")
        
        if not blocks:
            return [], []
        
        # Contract and whiten blocks
        blocks, g = self.contract_and_whiten_blocks(blocks, state_info, W)
        
        learned_effects = []
        learned_probs = []
        
        # Stable iterative extraction
        for outer_iter in range(self.max_effects):
            print(f"\nIteration {outer_iter + 1}:")
            
            # Check termination
            max_eigenval = 0
            active_blocks = 0
            
            for block in blocks:
                if block.size > 0:
                    try:
                        eigenvals, _ = eigh((block + block.T) / 2)
                        current_max = np.max(eigenvals)
                        if current_max > 1e-6:
                            max_eigenval = max(max_eigenval, current_max)
                            active_blocks += 1
                    except:
                        continue
            
            if max_eigenval < 1e-6 or active_blocks == 0:
                print("  Termination condition met")
                break
            
            # Binary search for tight lambda
            lambda_upper = max_eigenval
            lambda_lower = 1e-6
            
            best_result = None
            
            for _ in range(8):  # Limited iterations for stability
                lambda_mid = (lambda_upper + lambda_lower) / 2
                
                tight_blocks, tight_eigenvectors, achieved_lambda = self.solve_eigenvalue_problem_stable(
                    blocks, lambda_mid
                )
                
                if tight_blocks:
                    lambda_lower = lambda_mid
                    best_result = (tight_blocks, tight_eigenvectors, achieved_lambda)
                else:
                    lambda_upper = lambda_mid
            
            if best_result is None:
                print("  No solution found")
                break
            
            tight_blocks, tight_eigenvectors, final_lambda = best_result
            print(f"  Found {len(tight_blocks)} tight blocks, λ={final_lambda:.4f}")
            
            # Combine fragments
            global_effect = self.combine_fragments_stable(
                tight_blocks, tight_eigenvectors, state_info, W_inv
            )
            
            if np.sum(global_effect) == 0:
                print("  Empty effect vector")
                continue
            
            # Check for duplicates and terminate early
            is_duplicate = False
            for existing_effect in learned_effects:
                if np.array_equal(global_effect, existing_effect):
                    print("  Duplicate effect detected, terminating extraction")
                    is_duplicate = True
                    break
            
            if is_duplicate:
                break
            
            # Compute probability
            prob = final_lambda / (abs(np.dot(g, global_effect)) + 1e-6)
            prob = np.clip(prob, 0.01, 0.99)
            
            learned_effects.append(global_effect)
            learned_probs.append(prob)
            
            print(f"  Effect: {global_effect} (p={prob:.3f})")
            
            # Stable rank-1 subtraction
            self.subtract_rank1_stable(blocks, global_effect, final_lambda, state_info)
        
        # Normalize probabilities
        if learned_probs:
            total = sum(learned_probs)
            learned_probs = [p / total for p in learned_probs]
        
        return learned_effects, learned_probs
    def verify_theorems_stable(self, action_name, learned_effects, learned_probs, transitions):
        """Stable theorem verification"""
        true_effects = self.actions[action_name]['effects']
        true_probs = self.actions[action_name]['probabilities']
        
        print(f"\nGround Truth:")
        for i, (eff, prob) in enumerate(zip(true_effects, true_probs)):
            print(f"  {eff} (p={prob:.3f})")
            
        print(f"\nLearned (STABLE Algorithm 1):")
        for i, (eff, prob) in enumerate(zip(learned_effects, learned_probs)):
            print(f"  {eff} (p={prob:.3f})")
        
        # Robust TV distance
        tv_distance = self.compute_tv_distance_robust(true_effects, true_probs, learned_effects, learned_probs)
        safety_ok = tv_distance <= self.epsilon
        
        # Completeness check - can learned model achieve same transitions as ground truth?
        action_transitions = [t for t in transitions if t[1] == action_name]
        
        # Get ground truth effects that can be applied
        true_effects = self.actions[action_name]['effects']
        achievable_transitions = 0
        total_applicable = 0
        
        for pre_state, _, post_state in action_transitions:
            # Check if any ground truth effect could produce this transition
            can_achieve = False
            for true_effect in true_effects:
                # Apply effect to pre_state
                expected_post = pre_state.copy()
                for i, val in enumerate(true_effect):
                    if val == 1:
                        expected_post[i] = 1
                
                # Check if this matches the observed post_state
                if np.array_equal(expected_post, post_state):
                    can_achieve = True
                    break
            
            if can_achieve:
                total_applicable += 1
                
                # Check if learned model can also achieve this
                for learned_effect in learned_effects:
                    learned_post = pre_state.copy()
                    for i, val in enumerate(learned_effect):
                        if val == 1:
                            learned_post[i] = 1
                    
                    if np.array_equal(learned_post, post_state):
                        achievable_transitions += 1
                        break
        
        success_rate = achievable_transitions / total_applicable if total_applicable > 0 else 0
        completeness_ok = success_rate >= (1 - self.epsilon)
        
        print(f"\n{'='*60}")
        print(f"STABLE ALGORITHM 1 VERIFICATION")
        print(f"{'='*60}")
        print(f"Safety: TV distance {tv_distance:.4f} ≤ ε={self.epsilon} {'pass' if safety_ok else 'fail'}")
        print(f"Completeness: Success {success_rate:.4f} ≥ {1-self.epsilon:.4f} {'pass' if completeness_ok else 'fail'}")
        print(f"Overall: {'BOTH THEOREMS VERIFIED' if (safety_ok and completeness_ok) else 'VERIFICATION FAILED'}")
        
        return safety_ok, completeness_ok
    
    def compute_tv_distance_robust(self, true_effects, true_probs, learned_effects, learned_probs):
        """Robust TV distance computation"""
        if not learned_effects:
            return 1.0
        
        # Hungarian-style matching with stability
        n_true = len(true_effects)
        n_learned = len(learned_effects)
        
        # Compute distance matrix
        dist_matrix = np.full((n_true, n_learned), np.inf)
        
        for i, (true_eff, true_prob) in enumerate(zip(true_effects, true_probs)):
            for j, (learned_eff, learned_prob) in enumerate(zip(learned_effects, learned_probs)):
                # Hamming distance
                hamming = np.sum(np.abs(true_eff - learned_eff)) / len(true_eff)
                # Probability difference
                prob_diff = abs(true_prob - learned_prob)
                # Combined distance
                dist_matrix[i, j] = 0.5 * hamming + 0.5 * prob_diff
        
        # Greedy matching
        total_distance = 0.0
        used_learned = set()
        
        # Match true effects to learned effects
        for i in range(n_true):
            best_j = -1
            best_dist = np.inf
            
            for j in range(n_learned):
                if j not in used_learned and dist_matrix[i, j] < best_dist:
                    best_dist = dist_matrix[i, j]
                    best_j = j
            
            if best_j != -1 and best_dist < 1.0:  # Only match if reasonable
                used_learned.add(best_j)
                total_distance += best_dist
            else:
                # Unmatched true effect contributes its probability
                total_distance += true_probs[i]
        
        # Add unmatched learned effects
        for j in range(n_learned):
            if j not in used_learned:
                total_distance += learned_probs[j]
        
        # TV distance is half of L1 distance
        return min(1.0, total_distance / 2)

def run_stable_algorithm1():
    """Run stable Algorithm 1 experiment"""
    print("=== NUMERICALLY STABLE ALGORITHM 1 ===\n")
    
    # Use original working configuration
    ssam = SSAMFixed(n_fluents=7, max_effects=3, epsilon=0.24, delta=0.1)
    
    # Ground truth action - original working example
    ssam.generate_action('pickup', [[0, 2], [0, 1], [1]], [0.5, 0.3, 0.2])
    
    # Generate sufficient data
    np.random.seed(42)
    n_samples = 80000  # Original working sample size
    transitions = ssam.sample_trajectories('pickup', n_samples)
    print(f"Generated {n_samples} transitions")
    
    # Run stable algorithm
    learned_effects, learned_probs = ssam.algorithm1_stable(transitions, 'pickup')
    
    if learned_effects:
        safety_ok, completeness_ok = ssam.verify_theorems_stable(
            'pickup', learned_effects, learned_probs, transitions
        )
        
        print(f"\n{'='*60}")
        print(f"FINAL RESULTS")
        print(f"{'='*60}")
        print(f"Effects recovered: {len(learned_effects)}")
        print(f"Safety theorem: {'VERIFIED' if safety_ok else 'FAILED'}")
        print(f"Completeness theorem: {'VERIFIED' if completeness_ok else 'FAILED'}")
        print(f"Overall success: {'COMPLETE SUCCESS' if (safety_ok and completeness_ok) else 'PARTIAL SUCCESS'}")
        
        return ssam, learned_effects, learned_probs, safety_ok, completeness_ok
    else:
        print("Stable Algorithm 1 failed to recover effects")
        return None, None, None, False, False

if __name__ == "__main__":
    results = run_stable_algorithm1()

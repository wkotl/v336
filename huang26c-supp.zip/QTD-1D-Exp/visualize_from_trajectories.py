"""
Phase 3: Visualization from saved trajectories.

This script:
1. Loads saved trajectories from Phase 2
2. Plots TV distance vs NFE with custom NFE grids:
   - DSE: more points in 0-100 range (where it converges fast)
   - DDPM: more points in 500-1000 range (where it converges)
3. Plots histogram evolution comparison

Usage:
    python visualize_from_trajectories.py --target_seeds 1 2 3 --inference_seed 1
"""
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import argparse
import os

from samplers.trajectory_sampler import (
    compute_tv_vs_nfe,
    compute_tv_vs_nfe_continuous,
)


def create_dse_nfe_grid(max_nfe, n_points=100):
    """
    Create NFE grid for DSE with more points in 0-100 range.
    DSE converges quickly, so we want finer resolution early.
    All values are multiples of 5 (except 0 and max_nfe).
    """
    # More points early (0-100), fewer later
    # Use step of 2 for 0-100, step of 5 for 100+
    early_points = np.arange(0, min(101, max_nfe + 1), 2)  # 0, 2, 4, ..., 100
    late_points = np.arange(105, max_nfe + 1, 5)  # 105, 110, 115, ...
    nfe_grid = np.concatenate([early_points, late_points, [max_nfe]])
    return np.unique(nfe_grid.astype(int))


def create_ddpm_nfe_grid(max_nfe=1000, n_points=100):
    """
    Create NFE grid for DDPM with more points in 500-1000 range.
    DDPM converges later, so we want finer resolution at the end.
    All values are multiples of 5 or 10.
    """
    max_nfe = int(max_nfe)
    if max_nfe <= 0:
        return np.array([0], dtype=int)
    if max_nfe <= 500:
        step = 1 if max_nfe <= 50 else 5
        nfe_grid = np.concatenate([np.arange(0, max_nfe + 1, step), [max_nfe]])
        return np.unique(nfe_grid.astype(int))

    # Fewer points early (0-500), more later (500-1000)
    # Use step of 10 for 0-500, step of 5 for 500-1000
    early_points = np.arange(0, 501, 10)  # 0, 10, 20, ..., 500
    late_points = np.arange(505, max_nfe + 1, 5)  # 505, 510, 515, ...
    nfe_grid = np.concatenate([early_points, late_points, [max_nfe]])
    return np.unique(nfe_grid.astype(int))


def get_trajectory_path(model_type, data_type, num_categories, num_steps, target_seed, inference_seed, traj_dir):
    """Get the trajectory file path."""
    suffix = f"_target{target_seed}_infseed{inference_seed}"
    if model_type == 'dse':
        return f"{traj_dir}/dse_{data_type}_1d_{num_categories}cat{suffix}_trajectories.npz"
    else:  # ddpm
        return f"{traj_dir}/ddpm_{data_type}_1d_{num_categories}cat_{num_steps}numsteps{suffix}_trajectories.npz"


def load_trajectory_data(path):
    """Load trajectory data from npz file."""
    data = np.load(path, allow_pickle=True)
    trajectories = data['trajectories'].tolist()
    metadata = {key: data[key] for key in data.files if key != 'trajectories'}
    return trajectories, metadata


def plot_tv_vs_nfe(all_results, args, save_path):
    """
    Plot TV distance vs NFE with separate grids for DSE and DDPM.
    Uses custom template with individual seed trajectories as dashed lines,
    mean as thick solid line, and std as shaded region.
    
    Args:
        all_results: Dict of {target_seed: {'dse': (nfe_grid, tv), 'ddpm': (nfe_grid, tv)}}
        args: Arguments
        save_path: Path to save figure
    """
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Main colors for mean lines
    main_colors = {'dse': 'steelblue', 'ddpm': 'darkgreen'}
    markers = {'dse': 'o', 'ddpm': 's'}
    display_names = {'dse': 'QTD', 'ddpm': 'DDPM'}  # Display names for plots
    
    # Seed colors for individual trajectories (different colors per seed)
    seed_colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', 
                   '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']
    
    all_dse_tv_common = []  # Common grid TV for mean/std
    all_ddpm_tv_common = []
    all_dse_full = []  # Full grid (nfe_grid, tv) for individual plotting
    all_dse_actual_max_nfes = []
    dse_nfe_grid = None  # Common grid
    ddpm_nfe_grid = None
    target_seeds_list = []
    
    # Collect all results
    for target_seed, results in all_results.items():
        dse_nfe, dse_tv = results['dse']  # Common grid
        ddpm_nfe, ddpm_tv = results['ddpm']
        dse_actual_max_nfe = results.get('dse_actual_max_nfe', dse_nfe[-1])
        
        all_dse_tv_common.append(dse_tv)
        all_ddpm_tv_common.append(ddpm_tv)
        all_dse_actual_max_nfes.append(dse_actual_max_nfe)
        target_seeds_list.append(target_seed)
        
        # Store full grid data if available
        if 'dse_full' in results:
            all_dse_full.append(results['dse_full'])
        else:
            all_dse_full.append((dse_nfe, dse_tv))
        
        if dse_nfe_grid is None:
            dse_nfe_grid = dse_nfe
            ddpm_nfe_grid = ddpm_nfe
    
    all_dse_tv_common = np.array(all_dse_tv_common)
    all_ddpm_tv_common = np.array(all_ddpm_tv_common)
    
    # Compute statistics on common grid
    dse_mean = np.mean(all_dse_tv_common, axis=0)
    dse_std = np.std(all_dse_tv_common, axis=0)
    ddpm_mean = np.mean(all_ddpm_tv_common, axis=0)
    ddpm_std = np.std(all_ddpm_tv_common, axis=0)
    
    # 1. Plot individual seed trajectories as dashed lines with different colors
    # Use FULL grid for DSE to show actual trajectory lengths
    for seed_idx in range(len(all_dse_full)):
        seed_color = seed_colors[seed_idx % len(seed_colors)]
        
        # DSE individual trajectory with its actual full length
        dse_full_nfe, dse_full_tv = all_dse_full[seed_idx]
        ax.plot(dse_full_nfe, dse_full_tv, 
                linewidth=1.5, alpha=0.5, color=seed_color, linestyle='--')
        
        # DDPM individual trajectory (all same length = 1000)
        ax.plot(ddpm_nfe_grid, all_ddpm_tv_common[seed_idx], 
                linewidth=1.5, alpha=0.5, color=seed_color, linestyle=':')
    
    # Add legend entries for seed colors only (dashed lines to match individual trajectories)
    for seed_idx, target_seed in enumerate(target_seeds_list):
        seed_color = seed_colors[seed_idx % len(seed_colors)]
        ax.plot([], [], linewidth=2, color=seed_color, linestyle='--', 
                label=f'Seed {target_seed}', alpha=0.7)
    
    # 2. Fill std shaded regions (draw before mean lines so they're behind)
    ax.fill_between(dse_nfe_grid, dse_mean - dse_std, dse_mean + dse_std, 
                    alpha=0.15, color=main_colors['dse'], zorder=5)
    ax.fill_between(ddpm_nfe_grid, ddpm_mean - ddpm_std, ddpm_mean + ddpm_std, 
                    alpha=0.15, color=main_colors['ddpm'], zorder=5)
    
    # 3. Plot mean lines (thick solid lines with markers)
    dse_markevery = max(1, len(dse_nfe_grid) // 10)
    ddpm_markevery = max(1, len(ddpm_nfe_grid) // 10)
    
    ax.plot(dse_nfe_grid, dse_mean, linewidth=3.5, color=main_colors['dse'], 
            label=f'{display_names["dse"]} (mean)', marker=markers['dse'], 
            markersize=8, markevery=dse_markevery, zorder=10)
    ax.plot(ddpm_nfe_grid, ddpm_mean, linewidth=3.5, color=main_colors['ddpm'], 
            label=f'{display_names["ddpm"]} (mean)', marker=markers['ddpm'], 
            markersize=8, markevery=ddpm_markevery, zorder=10)
    
    # Beautification
    ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5, alpha=0.3)
    ax.set_xlabel('Number of Function Evaluations (NFE)', fontsize=22)
    ax.set_ylabel('Total Variation Distance', fontsize=22)
    
    # No title for cleaner look
    
    ax.grid(True, which='both', linestyle='--', alpha=0.4)
    ax.legend(fontsize=16, loc='upper right')
    ax.tick_params(axis='both', which='major', labelsize=16)
    
    # Axis limits
    ax.set_xlim(0, ddpm_nfe_grid.max())
    ax.set_ylim(0, 0.8)
    
    # Compute final TV from each seed's actual final point (full grid)
    final_dse_tvs = [full_tv[-1] for (_, full_tv) in all_dse_full]
    final_dse_mean = np.mean(final_dse_tvs)
    final_dse_std = np.std(final_dse_tvs)
    
    final_ddpm_tvs = all_ddpm_tv_common[:, -1]
    final_ddpm_mean = np.mean(final_ddpm_tvs)
    final_ddpm_std = np.std(final_ddpm_tvs)
    
    # Compute mean max NFE across seeds
    mean_dse_max_nfe = int(np.mean(all_dse_actual_max_nfes))
    ddpm_max_nfe = int(ddpm_nfe_grid[-1])
    
    # Build simplified text box with mean ± std and mean max NFE
    textstr = f'Final TV (mean ± std):\n'
    textstr += f'  {display_names["dse"]}:  {final_dse_mean:.4f} ± {final_dse_std:.4f} (mean max NFE: {mean_dse_max_nfe})\n'
    textstr += f'  {display_names["ddpm"]}: {final_ddpm_mean:.4f} ± {final_ddpm_std:.4f} (NFE: {ddpm_max_nfe})'
    
    props = dict(boxstyle='round', facecolor='wheat', alpha=0.8)
    ax.text(0.02, 0.98, textstr, transform=ax.transAxes, fontsize=14,
            verticalalignment='top', bbox=props, family='monospace')
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    
    # Also save as PDF
    pdf_path = save_path.replace('.png', '.pdf')
    plt.savefig(pdf_path, dpi=300, bbox_inches='tight')
    
    plt.close()
    print(f"Saved TV vs NFE plot to {save_path}")
    print(f"Saved TV vs NFE plot to {pdf_path}")


def plot_combined_histogram_evolution(dse_data, ddpm_data, dse_nfe_checkpoints, ddpm_nfe_checkpoints, save_path=None):
    """
    Plot DSE and DDPM histogram evolution side-by-side with separate NFE checkpoints.
    
    Colors:
    - Light gray for target distribution
    - Blue (steelblue) for DSE
    - Green (darkgreen) for DDPM
    
    Args:
        dse_data: Dict with 'nfe_grid', 'histograms', 'true_dist', 'num_categories', 'x_min', 'x_max'
        ddpm_data: Dict with same structure
        dse_nfe_checkpoints: List of NFE values for DSE (top row)
        ddpm_nfe_checkpoints: List of NFE values for DDPM (bottom row)
        save_path: Path to save figure
    """
    n_dse = len(dse_nfe_checkpoints)
    n_ddpm = len(ddpm_nfe_checkpoints)
    n_cols = max(n_dse, n_ddpm)
    
    # Compact figure with square plot areas
    subplot_width = 1.8  # Width per subplot
    subplot_height = 2.5  # Height per subplot (includes title)
    fig, axes = plt.subplots(2, n_cols, figsize=(subplot_width * n_cols, subplot_height * 2))
    
    num_categories = dse_data['num_categories']
    true_dist = dse_data['true_dist']
    x_min = dse_data['x_min']
    x_max = dse_data['x_max']
    
    # Colors and display names matching TV vs NFE plot
    color_target = 'lightgray'
    color_dse = 'steelblue'
    color_ddpm = 'darkgreen'
    display_name_dse = 'QTD'
    display_name_ddpm = 'DDPM'
    
    # X-axis values (bin centers)
    if x_min is not None and not np.isnan(x_min):
        bin_edges = np.linspace(x_min, x_max, num_categories + 1)
        bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
    else:
        bin_centers = np.arange(num_categories)
    
    bar_width = (bin_centers[1] - bin_centers[0]) * 0.9
    
    dse_nfe_grid = dse_data['nfe_grid']
    dse_histograms = dse_data['histograms']
    ddpm_nfe_grid = ddpm_data['nfe_grid']
    ddpm_histograms = ddpm_data['histograms']
    
    # === DSE (top row) ===
    for col, nfe_target in enumerate(dse_nfe_checkpoints):
        ax_dse = axes[0, col]
        
        idx_dse = np.argmin(np.abs(dse_nfe_grid - nfe_target))
        nfe_dse_actual = dse_nfe_grid[idx_dse]
        emp_dist_dse = dse_histograms[idx_dse]
        tv_dse = 0.5 * np.sum(np.abs(emp_dist_dse - true_dist))
        
        ax_dse.bar(bin_centers, true_dist, alpha=0.7, color=color_target, label='Target', width=bar_width, zorder=1)
        ax_dse.bar(bin_centers, emp_dist_dse, alpha=0.6, color=color_dse, label=display_name_dse, width=bar_width, zorder=2)
        ax_dse.set_title(f'{display_name_dse} | NFE={int(nfe_dse_actual)}\nTV={tv_dse:.4f}', fontsize=12, fontweight='bold')
        ax_dse.tick_params(axis='both', which='major', labelsize=10)
        ax_dse.set_xticks([-2, 0, 2])  # Only show -2, 0, 2 on x-axis
        ax_dse.set_box_aspect(1)  # Make plot area square
        
        # Only show y-axis label and ticks for leftmost subplot
        if col == 0:
            ax_dse.set_ylabel('Probability', fontsize=12)
            ax_dse.legend(fontsize=11, loc='upper right')
        else:
            ax_dse.set_yticklabels([])
    
    # Hide unused DSE subplots
    for col in range(n_dse, n_cols):
        axes[0, col].axis('off')
    
    # === DDPM (bottom row) ===
    for col, nfe_target in enumerate(ddpm_nfe_checkpoints):
        ax_ddpm = axes[1, col]
        
        idx_ddpm = np.argmin(np.abs(ddpm_nfe_grid - nfe_target))
        nfe_ddpm_actual = ddpm_nfe_grid[idx_ddpm]
        emp_dist_ddpm = ddpm_histograms[idx_ddpm]
        tv_ddpm = 0.5 * np.sum(np.abs(emp_dist_ddpm - true_dist))
        
        ax_ddpm.bar(bin_centers, true_dist, alpha=0.7, color=color_target, label='Target', width=bar_width, zorder=1)
        ax_ddpm.bar(bin_centers, emp_dist_ddpm, alpha=0.6, color=color_ddpm, label=display_name_ddpm, width=bar_width, zorder=2)
        ax_ddpm.set_title(f'{display_name_ddpm} | NFE={int(nfe_ddpm_actual)}\nTV={tv_ddpm:.4f}', fontsize=12, fontweight='bold')
        ax_ddpm.tick_params(axis='both', which='major', labelsize=10)
        ax_ddpm.set_xticks([-2, 0, 2])  # Only show -2, 0, 2 on x-axis
        ax_ddpm.set_box_aspect(1)  # Make plot area square
        
        # Only show y-axis label and ticks for leftmost subplot
        if col == 0:
            ax_ddpm.set_ylabel('Probability', fontsize=12)
            ax_ddpm.legend(fontsize=11, loc='upper right')
        else:
            ax_ddpm.set_yticklabels([])
    
    # Hide unused DDPM subplots
    for col in range(n_ddpm, n_cols):
        axes[1, col].axis('off')
    
    # No title for cleaner look, compact spacing
    plt.tight_layout(pad=0.5)
    plt.subplots_adjust(wspace=0.08, hspace=0.03)  # Reduced horizontal spacing
    
    if save_path:
        # Save PNG
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Figure saved to {save_path}")
        
        # Save PDF
        pdf_path = save_path.replace('.png', '.pdf')
        plt.savefig(pdf_path, dpi=300, bbox_inches='tight')
        print(f"Figure saved to {pdf_path}")
    
    plt.close()


def main():
    parser = argparse.ArgumentParser(description="Visualize from saved trajectories")
    
    # Seed configuration
    parser.add_argument("--target_seeds", type=int, nargs='+', default=[1],
                        help="Target seeds to include in visualization")
    parser.add_argument("--inference_seed", type=int, default=1,
                        help="Inference seed used when generating trajectories (ignored if --use_target_as_inference_seed)")
    parser.add_argument("--use_target_as_inference_seed", action="store_true",
                        help="Use target_seed as inference_seed for each target")
    
    # Data params
    parser.add_argument("--data_type", type=str, default="GMM", 
                        choices=["discrete", "continuous", "GMM"])
    parser.add_argument("--num_categories", type=int, default=128)
    parser.add_argument("--num_steps", type=int, default=1000)
    
    # NFE grid params
    parser.add_argument("--n_grid_points", type=int, default=100,
                        help="Number of NFE points in grid")
    
    # Histogram evolution checkpoints
    # Note: For DSE, if max_nfe is provided (e.g., from trajectory data), it will be appended
    parser.add_argument("--dse_hist_checkpoints", type=int, nargs='+', 
                        default=[0, 30, 50, 60, 70, 80, 100, 150],
                        help="NFE checkpoints for DSE histogram evolution (max NFE will be appended)")
    parser.add_argument("--ddpm_hist_checkpoints", type=int, nargs='+', 
                        default=[0, 100, 250, 500, 600, 700, 800, 900, 1000],
                        help="NFE checkpoints for DDPM histogram evolution")
    
    # Paths
    parser.add_argument("--traj_dir", type=str, default="./trajectories/")
    parser.add_argument("--save_dir", type=str, default="./comparison_results/")
    
    args = parser.parse_args()
    
    os.makedirs(args.save_dir, exist_ok=True)
    
    print("="*70)
    print("Phase 3: Visualization from Saved Trajectories")
    print("="*70)
    print(f"Data type: {args.data_type}")
    print(f"Target seeds: {args.target_seeds}")
    if args.use_target_as_inference_seed:
        print(f"Inference seed: use target_seed for each")
    else:
        print(f"Inference seed: {args.inference_seed}")
    print(f"Trajectory directory: {args.traj_dir}")
    print(f"Save directory: {args.save_dir}")
    print("="*70)
    
    all_results = {}
    first_dse_data = None
    first_ddpm_data = None
    
    # First pass: find the minimum max_nfe across all seeds to create a common grid
    all_dse_max_nfes = []
    for target_seed in args.target_seeds:
        inference_seed = target_seed if args.use_target_as_inference_seed else args.inference_seed
        dse_traj_path = get_trajectory_path('dse', args.data_type, args.num_categories,
                                             args.num_steps, target_seed, inference_seed, args.traj_dir)
        if os.path.exists(dse_traj_path):
            data = np.load(dse_traj_path, allow_pickle=True)
            trajectories = data['trajectories'].tolist()
            max_nfe = max([traj[-1][1] for traj in trajectories if len(traj) > 0])
            all_dse_max_nfes.append(max_nfe)
    
    # Use minimum max_nfe to create common grid (ensures all seeds have data at all points)
    common_dse_max_nfe = min(all_dse_max_nfes) if all_dse_max_nfes else 200
    common_dse_nfe_grid = create_dse_nfe_grid(common_dse_max_nfe, args.n_grid_points)
    common_ddpm_nfe_grid = create_ddpm_nfe_grid(args.num_steps, args.n_grid_points)
    
    print(f"\nCommon DSE NFE grid: {len(common_dse_nfe_grid)} points, range [0, {common_dse_max_nfe}]")
    print(f"Common DDPM NFE grid: {len(common_ddpm_nfe_grid)} points, range [0, {args.num_steps}]")
    print(f"Individual DSE max NFEs: {all_dse_max_nfes}")
    
    for target_seed in args.target_seeds:
        # Determine inference seed for this target
        inference_seed = target_seed if args.use_target_as_inference_seed else args.inference_seed
        
        print(f"\nProcessing target seed {target_seed} (inference seed {inference_seed})...")
        
        # Load trajectories
        dse_traj_path = get_trajectory_path('dse', args.data_type, args.num_categories,
                                             args.num_steps, target_seed, inference_seed, args.traj_dir)
        ddpm_traj_path = get_trajectory_path('ddpm', args.data_type, args.num_categories,
                                              args.num_steps, target_seed, inference_seed, args.traj_dir)
        
        if not os.path.exists(dse_traj_path):
            print(f"ERROR: DSE trajectory not found at {dse_traj_path}")
            continue
        if not os.path.exists(ddpm_traj_path):
            print(f"ERROR: DDPM trajectory not found at {ddpm_traj_path}")
            continue
        
        print(f"  Loading DSE trajectories from {dse_traj_path}")
        dse_trajectories, dse_metadata = load_trajectory_data(dse_traj_path)
        
        print(f"  Loading DDPM trajectories from {ddpm_traj_path}")
        ddpm_trajectories, ddpm_metadata = load_trajectory_data(ddpm_traj_path)
        
        # Get true distribution
        true_dist = dse_metadata['true_dist']
        # Handle numpy array stored in npz (may be wrapped in 0-d object array)
        if hasattr(true_dist, 'ndim') and true_dist.ndim == 0:
            true_dist = true_dist.item()  # Unwrap 0-d object array
        elif hasattr(true_dist, 'flatten'):
            true_dist = np.array(true_dist).flatten()  # Ensure it's a 1D numpy array
        
        disc_mean = float(dse_metadata['disc_mean'])
        disc_std = float(dse_metadata['disc_std'])
        x_min = dse_metadata.get('disc_x_min', None)
        x_max = dse_metadata.get('disc_x_max', None)
        if x_min is not None and hasattr(x_min, 'item'):
            x_min = float(x_min)
        if x_max is not None and hasattr(x_max, 'item'):
            x_max = float(x_max)
        
        # Find actual max NFE for this seed (for reference)
        dse_actual_max_nfe = max([traj[-1][1] for traj in dse_trajectories if len(traj) > 0])
        
        print(f"  This seed's actual max NFE: {dse_actual_max_nfe}")
        
        # Compute TV on COMMON grid (for mean/std calculation)
        print(f"  Computing TV vs NFE for DSE (common grid)...")
        _, dse_tv_common, dse_histograms = compute_tv_vs_nfe(
            dse_trajectories, true_dist, args.num_categories,
            nfe_grid=common_dse_nfe_grid, return_histograms=True
        )
        
        print(f"  Computing TV vs NFE for DDPM (common grid)...")
        _, ddpm_tv_common, ddpm_histograms = compute_tv_vs_nfe_continuous(
            ddpm_trajectories, true_dist, args.num_categories,
            mean=disc_mean, std=disc_std,
            nfe_grid=common_ddpm_nfe_grid, return_histograms=True
        )
        
        # Compute TV on INDIVIDUAL seed's full grid (for plotting individual curves)
        print(f"  Computing TV vs NFE for DSE (individual full grid up to {dse_actual_max_nfe})...")
        dse_full_nfe_grid = create_dse_nfe_grid(dse_actual_max_nfe, args.n_grid_points)
        dse_full_nfe_grid, dse_tv_full, _ = compute_tv_vs_nfe(
            dse_trajectories, true_dist, args.num_categories,
            nfe_grid=dse_full_nfe_grid, return_histograms=True
        )
        
        all_results[target_seed] = {
            'dse': (common_dse_nfe_grid, dse_tv_common),  # Common grid for mean/std
            'ddpm': (common_ddpm_nfe_grid, ddpm_tv_common),
            'dse_full': (dse_full_nfe_grid, dse_tv_full),  # Full grid for individual plotting
            'dse_actual_max_nfe': dse_actual_max_nfe
        }
        
        # Use common grid variables for histogram evolution
        dse_nfe_grid = common_dse_nfe_grid
        ddpm_nfe_grid = common_ddpm_nfe_grid
        
        # Store first seed's data for histogram evolution plots
        if first_dse_data is None:
            # Get DSE max NFE for checkpoint list
            dse_max_nfe_val = int(dse_nfe_grid[-1])
            
            first_dse_data = {
                'nfe_grid': dse_nfe_grid,
                'histograms': dse_histograms,
                'true_dist': true_dist,
                'num_categories': args.num_categories,
                'x_min': x_min,
                'x_max': x_max,
                'max_nfe': dse_max_nfe_val
            }
            first_ddpm_data = {
                'nfe_grid': ddpm_nfe_grid,
                'histograms': ddpm_histograms,
                'true_dist': true_dist,
                'num_categories': args.num_categories,
                'x_min': x_min,
                'x_max': x_max
            }
        
        print(f"  DSE final TV: {dse_tv_full[-1]:.4f} at NFE={dse_full_nfe_grid[-1]}")
        print(f"  DDPM final TV: {ddpm_tv_common[-1]:.4f} at NFE={common_ddpm_nfe_grid[-1]}")
    
    if not all_results:
        print("ERROR: No trajectories loaded. Run Phase 2 first.")
        return
    
    # Plot TV vs NFE
    print("\nPlotting TV vs NFE...")
    plot_tv_vs_nfe(all_results, args, os.path.join(args.save_dir, "tv_vs_nfe_multi_seed.png"))
    
    # Plot histogram evolution (using first target seed)
    if first_dse_data is not None:
        # Create DSE checkpoints with max NFE appended
        dse_max_nfe = first_dse_data['max_nfe']
        dse_checkpoints = args.dse_hist_checkpoints + [dse_max_nfe]
        # Remove duplicates and sort
        dse_checkpoints = sorted(list(set(dse_checkpoints)))
        
        print(f"\nDSE histogram checkpoints: {dse_checkpoints}")
        print(f"DDPM histogram checkpoints: {args.ddpm_hist_checkpoints}")
        
        print("Plotting combined histogram evolution...")
        plot_combined_histogram_evolution(
            first_dse_data, first_ddpm_data,
            dse_nfe_checkpoints=dse_checkpoints,
            ddpm_nfe_checkpoints=args.ddpm_hist_checkpoints,
            save_path=os.path.join(args.save_dir, "histogram_evolution_comparison.png")
        )
    
    # Save numerical results
    npz_path = os.path.join(args.save_dir, "tv_vs_nfe_multi_seed.npz")
    save_data = {
        'target_seeds': np.array(args.target_seeds),
        'inference_seed': args.inference_seed,
        'data_type': args.data_type,
    }
    for target_seed, results in all_results.items():
        save_data[f'dse_nfe_grid_t{target_seed}'] = results['dse'][0]  # Common grid
        save_data[f'dse_tv_t{target_seed}'] = results['dse'][1]
        save_data[f'ddpm_nfe_grid_t{target_seed}'] = results['ddpm'][0]
        save_data[f'ddpm_tv_t{target_seed}'] = results['ddpm'][1]
        save_data[f'dse_actual_max_nfe_t{target_seed}'] = results['dse_actual_max_nfe']
        # Also save full grid data
        if 'dse_full' in results:
            save_data[f'dse_full_nfe_grid_t{target_seed}'] = results['dse_full'][0]
            save_data[f'dse_full_tv_t{target_seed}'] = results['dse_full'][1]
    
    np.savez(npz_path, **save_data)
    print(f"\nSaved results to {npz_path}")
    
    # Print summary
    print("\n" + "="*70)
    print("Summary: Final TV Distance")
    print("="*70)
    print(f"{'Target Seed':>12} | {'QTD TV':>10} | {'QTD NFE':>8} | {'DDPM TV':>10} | {'DDPM NFE':>8}")
    print("-"*60)
    for target_seed, results in all_results.items():
        ddpm_nfe, ddpm_tv = results['ddpm']
        # Use full grid data for DSE if available
        if 'dse_full' in results:
            dse_full_nfe, dse_full_tv = results['dse_full']
            print(f"{target_seed:>12} | {dse_full_tv[-1]:>10.4f} | {dse_full_nfe[-1]:>8} | {ddpm_tv[-1]:>10.4f} | {ddpm_nfe[-1]:>8}")
        else:
            dse_nfe, dse_tv = results['dse']
            print(f"{target_seed:>12} | {dse_tv[-1]:>10.4f} | {dse_nfe[-1]:>8} | {ddpm_tv[-1]:>10.4f} | {ddpm_nfe[-1]:>8}")
    print("="*70)
    
    print("\nPhase 3 Complete!")


if __name__ == "__main__":
    main()

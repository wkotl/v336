"""
Trajectory-based samplers for DSE and DDPM.
Records full trajectory (state, cumulative_nfe) at every step for post-hoc TV analysis.

This is more efficient than running separate sampling for each checkpoint:
- Run sampling ONCE per trajectory
- Post-process to compute TV at ANY NFE value without re-running
"""
import numpy as np
import math
import torch
from tqdm import trange, tqdm


# ============================================================================
# DSE (Truncated Uniformization) Trajectory Sampler
# ============================================================================

def time_beta_sequence_construction(mixing_time, delta_time, num_K):
    """Construct time and beta sequences."""
    temp_time_list = []
    temp_beta_list = []
    current_time = 0
    beta_constant = 2 * math.log2(num_K)
    while current_time < mixing_time - delta_time:
        temp_time_list.append(current_time)
        temp_beta_list.append(beta_constant / min(1.0, mixing_time - current_time))
        current_time = (current_time + mixing_time * 0.5) / 1.5
    temp_time_list.append(current_time)
    temp_beta_list.append(beta_constant / min(1.0, mixing_time - current_time))
    return len(temp_time_list), torch.tensor(temp_time_list, dtype=torch.float32), torch.tensor(temp_beta_list, dtype=torch.float32)


@torch.no_grad()
def dse_trajectory_sampler(model, num_samples, mixing_time, delta_time, num_K, device='cpu', show_progress=True, batch_size=512):
    """
    BATCHED DSE sampler that records full trajectory for each sample.
    Processes multiple samples in parallel for significant speedup.
    
    Args:
        model: Trained DSE model
        num_samples: Number of samples (trajectories) to generate
        mixing_time: Maximum diffusion time
        delta_time: Time step precision
        num_K: Number of categories
        device: Device for computation
        show_progress: Whether to show progress bar
        batch_size: Number of samples to process in parallel
        
    Returns:
        trajectories: List of trajectories, each trajectory is list of [state, nfe] pairs
        final_states: List of final states (for quick access)
    """
    model.eval()
    
    num_W, time_sequence, beta_sequence = time_beta_sequence_construction(
        mixing_time=mixing_time, delta_time=delta_time, num_K=num_K
    )
    time_sequence = time_sequence.to(device)
    beta_sequence = beta_sequence.to(device)
    
    bin_len = int(math.log2(num_K))
    flip_values = (2 ** torch.arange(bin_len - 1, -1, -1, dtype=torch.int64, device=device))
    
    all_trajectories = []
    all_final_states = []
    
    num_batches = (num_samples + batch_size - 1) // batch_size
    iterator = trange(num_batches, desc=f"DSE Sampling ({num_samples} samples, batch={batch_size})") if show_progress else range(num_batches)
    
    for batch_idx in iterator:
        current_batch_size = min(batch_size, num_samples - batch_idx * batch_size)
        
        # Initialize batch of Y values
        Y_batch = Y_initialization_batch(num_K, current_batch_size, device)
        
        # Initialize trajectories and NFE counters for this batch
        batch_trajectories = [[[int(Y_batch[i].item()), 0]] for i in range(current_batch_size)]
        cumulative_nfe = np.zeros(current_batch_size, dtype=np.int32)
        
        # Run sampling for all samples in batch
        for w in range(1, num_W):
            time_start = float(time_sequence[w - 1])
            time_end = float(time_sequence[w])
            
            lam = float(beta_sequence[w]) * (time_end - time_start)
            # Sample Poisson for each sample in batch
            inner_iteration_nums = np.random.poisson(lam=lam, size=current_batch_size)
            max_iters = int(inner_iteration_nums.max()) if inner_iteration_nums.max() > 0 else 0
            
            if max_iters == 0:
                continue
            
            # Process each iteration
            for n in range(max_iters):
                # Find active samples (those that have more iterations)
                active_mask = inner_iteration_nums > n
                if not active_mask.any():
                    continue
                
                active_indices = np.where(active_mask)[0]
                num_active = len(active_indices)
                
                # Generate timestamps for active samples
                timestamps = torch.empty(num_active, device=device).uniform_(time_start, time_end)
                current_times = mixing_time - timestamps
                
                # Get Y values for active samples
                Y_active = Y_batch[active_indices]
                
                # BATCHED model call - key speedup!
                current_scores = torch.exp(model(Y_active.long(), current_times))
                
                # Update NFE for active samples
                cumulative_nfe[active_indices] += 1
                
                # Process each active sample
                for i, (local_idx, global_idx) in enumerate(zip(range(num_active), active_indices)):
                    current_score = current_scores[i]
                    current_time = current_times[i]
                    current_beta = 2 * bin_len / min(1.0, float(current_time))
                    
                    score_sum = current_score.sum()
                    if score_sum > current_beta:
                        current_score = current_score / score_sum * current_beta
                    current_score = current_score / current_beta
                    
                    lazy_prob = max(0.0, 1.0 - current_score.sum().item())
                    flip_probs = torch.cat([current_score, torch.tensor([lazy_prob], device=device)])
                    
                    sample_idx_flip = torch.multinomial(flip_probs, 1).item()
                    
                    if sample_idx_flip < bin_len:
                        Y_batch[global_idx] = Y_batch[global_idx] ^ flip_values[sample_idx_flip]
                    
                    # Record state after this step
                    batch_trajectories[global_idx].append([int(Y_batch[global_idx].item()), int(cumulative_nfe[global_idx])])
        
        # Add batch results to overall results
        all_trajectories.extend(batch_trajectories)
        all_final_states.extend(Y_batch.cpu().tolist())
    
    return all_trajectories, all_final_states


def Y_initialization_batch(num_K, batch_size, device='cpu'):
    """Initialize Y values for a batch of samples (vectorized)."""
    bin_len = int(math.log2(num_K))
    weight_tensor = (2 ** torch.arange(bin_len - 1, -1, -1, dtype=torch.int64, device=device))
    binary_tensor = torch.bernoulli(torch.ones(batch_size, bin_len, device=device) * 0.5).to(torch.int64)
    return (binary_tensor * weight_tensor).sum(dim=1)


# ============================================================================
# DDPM Trajectory Sampler
# ============================================================================

@torch.no_grad()
def ddpm_trajectory_sampler(model, num_samples, num_steps=1000, device='cpu', show_progress=True):
    """
    DDPM sampler that records full trajectory for each sample.
    
    Args:
        model: Trained DDPM model
        num_samples: Number of samples (trajectories) to generate
        num_steps: Total number of denoising steps
        device: Device for computation
        show_progress: Whether to show progress bar
        
    Returns:
        trajectories: List of trajectories, each trajectory is list of [state, nfe] pairs
                     State is continuous (float), NFE = num_steps - current_step
        final_states: Tensor of final continuous states
    """
    model.eval()
    
    # DDPM noise schedule
    beta_start = 0.0001
    beta_end = 0.02
    betas = torch.linspace(beta_start, beta_end, num_steps, device=device)
    alphas = 1.0 - betas
    alpha_bar = torch.cumprod(alphas, dim=0)
    
    # Pre-compute coefficients
    coeff1 = 1.0 / torch.sqrt(alphas)
    coeff2 = (1.0 - alphas) / torch.sqrt(1.0 - alpha_bar)
    sigma = torch.sqrt(betas)
    
    # Start from pure noise
    x_t = torch.randn(num_samples, device=device)
    
    # Initialize trajectories - record initial state (pure noise, nfe=0)
    # Each trajectory: list of [state, nfe]
    trajectories = [[[] for _ in range(num_samples)] for _ in range(1)]  # Placeholder
    trajectories = []
    for i in range(num_samples):
        trajectories.append([[float(x_t[i].item()), 0]])
    
    iterator = tqdm(reversed(range(num_steps)), total=num_steps, desc=f"DDPM Sampling ({num_samples} samples, {num_steps} steps)") if show_progress else reversed(range(num_steps))
    
    for t in iterator:
        # Current timestep tensor
        t_tensor = torch.full((num_samples,), t, dtype=torch.long, device=device)
        
        # Model call - NFE increments by 1 for all samples
        predicted_noise = model(x_t, t_tensor)
        current_nfe = num_steps - t  # NFE = how many steps we've taken
        
        # DDPM reverse step
        x_t = coeff1[t] * (x_t - coeff2[t] * predicted_noise)
        
        # Add noise if not final step
        if t > 0:
            x_t = x_t + sigma[t] * torch.randn_like(x_t)
        
        # Record state for all trajectories
        for i in range(num_samples):
            trajectories[i].append([float(x_t[i].item()), current_nfe])
    
    final_states = x_t
    
    return trajectories, final_states


# ============================================================================
# Post-processing: Compute TV Distance vs NFE
# ============================================================================

def compute_tv_vs_nfe(trajectories, true_distribution, num_categories, nfe_grid=None, n_grid_points=50,
                      return_histograms=False):
    """
    Compute TV distance as a function of NFE from trajectory data.
    
    Args:
        trajectories: List of trajectories, each trajectory is list of [state, nfe] pairs
        true_distribution: True probability distribution (numpy array, sums to 1)
        num_categories: Number of discrete categories
        nfe_grid: Optional array of NFE values to evaluate at. If None, auto-generated.
        n_grid_points: Number of NFE points if nfe_grid is None
        return_histograms: If True, also return empirical distributions at each NFE
        
    Returns:
        nfe_grid: Array of NFE values
        tv_distances: Array of TV distances at each NFE point
        (optional) histograms: List of empirical distributions at each NFE point
    """
    # Ensure true_distribution is numpy array
    if hasattr(true_distribution, 'detach'):
        true_distribution = true_distribution.detach().cpu().numpy()
    
    # Find NFE range across all trajectories
    min_nfe = float('inf')
    max_nfe = 0
    
    for traj in trajectories:
        if len(traj) > 0:
            traj_nfes = [entry[1] for entry in traj]
            min_nfe = min(min_nfe, min(traj_nfes))
            max_nfe = max(max_nfe, max(traj_nfes))
    
    # Create NFE grid
    if nfe_grid is None:
        nfe_grid = np.linspace(min_nfe, max_nfe, n_grid_points)
    
    # For each NFE target, collect states and compute TV
    tv_distances = []
    histograms = [] if return_histograms else None
    
    for nfe_target in nfe_grid:
        states_at_nfe = []
        
        for traj in trajectories:
            if len(traj) == 0:
                continue
            
            # Binary search for largest NFE <= nfe_target
            state = find_state_at_nfe(traj, nfe_target)
            states_at_nfe.append(state)
        
        if len(states_at_nfe) == 0:
            tv_distances.append(1.0)  # Maximum TV if no states
            if return_histograms:
                histograms.append(np.ones(num_categories) / num_categories)
            continue
        
        # Build empirical distribution
        empirical_dist = np.zeros(num_categories)
        for state in states_at_nfe:
            state_idx = int(state) % num_categories  # Ensure valid index
            empirical_dist[state_idx] += 1
        empirical_dist /= len(states_at_nfe)
        
        # Compute TV distance: 0.5 * sum(|p - q|)
        tv_distance = 0.5 * np.sum(np.abs(empirical_dist - true_distribution))
        tv_distances.append(tv_distance)
        
        if return_histograms:
            histograms.append(empirical_dist.copy())
    
    if return_histograms:
        return nfe_grid, np.array(tv_distances), histograms
    return nfe_grid, np.array(tv_distances)


def compute_tv_vs_nfe_continuous(trajectories, true_distribution, num_categories, 
                                  mean=8.0, std=2.0, range_factor=3.0,
                                  nfe_grid=None, n_grid_points=50,
                                  return_histograms=False):
    """
    Compute TV distance as a function of NFE for continuous DDPM trajectories.
    Discretizes continuous states before computing TV.
    
    Args:
        trajectories: List of trajectories, each trajectory is list of [continuous_state, nfe] pairs
        true_distribution: True probability distribution (numpy array)
        num_categories: Number of discrete categories for binning
        mean, std, range_factor: Discretization parameters
        nfe_grid: Optional array of NFE values
        n_grid_points: Number of NFE points if nfe_grid is None
        return_histograms: If True, also return empirical distributions at each NFE
        
    Returns:
        nfe_grid: Array of NFE values
        tv_distances: Array of TV distances
        (optional) histograms: List of empirical distributions at each NFE point
    """
    # Ensure true_distribution is numpy array
    if hasattr(true_distribution, 'detach'):
        true_distribution = true_distribution.detach().cpu().numpy()
    
    # Discretization bins (same as create_1d_continuous_distribution)
    x_min = mean - range_factor * std
    x_max = mean + range_factor * std
    bin_edges = np.linspace(x_min, x_max, num_categories + 1)
    
    # Find NFE range
    min_nfe = float('inf')
    max_nfe = 0
    
    for traj in trajectories:
        if len(traj) > 0:
            traj_nfes = [entry[1] for entry in traj]
            min_nfe = min(min_nfe, min(traj_nfes))
            max_nfe = max(max_nfe, max(traj_nfes))
    
    # Create NFE grid
    if nfe_grid is None:
        nfe_grid = np.linspace(min_nfe, max_nfe, n_grid_points)
    
    # Compute TV at each NFE point
    tv_distances = []
    histograms = [] if return_histograms else None
    
    for nfe_target in nfe_grid:
        continuous_states = []
        
        for traj in trajectories:
            if len(traj) == 0:
                continue
            state = find_state_at_nfe(traj, nfe_target)
            continuous_states.append(state)
        
        if len(continuous_states) == 0:
            tv_distances.append(1.0)
            if return_histograms:
                histograms.append(np.ones(num_categories) / num_categories)
            continue
        
        # Discretize continuous states
        continuous_states = np.array(continuous_states)
        discrete_states = np.digitize(continuous_states, bin_edges) - 1
        discrete_states = np.clip(discrete_states, 0, num_categories - 1)
        
        # Build empirical distribution
        empirical_dist = np.zeros(num_categories)
        for state_idx in discrete_states:
            empirical_dist[state_idx] += 1
        empirical_dist /= len(discrete_states)
        
        # Compute TV distance
        tv_distance = 0.5 * np.sum(np.abs(empirical_dist - true_distribution))
        tv_distances.append(tv_distance)
        
        if return_histograms:
            histograms.append(empirical_dist.copy())
    
    if return_histograms:
        return nfe_grid, np.array(tv_distances), histograms
    return nfe_grid, np.array(tv_distances)


def find_state_at_nfe(trajectory, nfe_target):
    """
    Binary search to find state at target NFE.
    Returns state corresponding to largest NFE <= nfe_target.
    
    Args:
        trajectory: List of [state, nfe] pairs, sorted by NFE (ascending)
        nfe_target: Target NFE value
        
    Returns:
        state: State at the target NFE
    """
    if len(trajectory) == 0:
        raise ValueError("Empty trajectory")
    
    # Edge cases
    if nfe_target <= trajectory[0][1]:
        return trajectory[0][0]
    if nfe_target >= trajectory[-1][1]:
        return trajectory[-1][0]
    
    # Binary search for largest NFE <= nfe_target
    left, right = 0, len(trajectory) - 1
    while left < right:
        mid = (left + right + 1) // 2
        if trajectory[mid][1] <= nfe_target:
            left = mid
        else:
            right = mid - 1
    
    return trajectory[left][0]


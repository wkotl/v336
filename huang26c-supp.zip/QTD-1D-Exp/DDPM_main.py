"""Train or load the continuous DDPM baseline."""

import numpy as np
import torch

from configs.arg_parser import dse_parse_args
from modules.data_generation import (
    create_1d_continuous_distribution,
    create_1d_gmm_distribution,
    create_1d_true_distribution,
    get_gmm_params,
)
from modules.trainer import load_model, train_ddpm


def build_target_distribution(args):
    """Create the target distribution and GMM metadata used by DDPM."""
    if args.data_type == "discrete":
        categories, p_data = create_1d_true_distribution(args.num_categories)
        return categories, p_data, None
    if args.data_type == "continuous":
        categories, p_data = create_1d_continuous_distribution(args.num_categories, mean=8.0, std=2.0)
        return categories, p_data, None
    if args.data_type == "GMM":
        gmm_params = get_gmm_params()
        categories, p_data = create_1d_gmm_distribution(
            args.num_categories,
            means=gmm_params["means"],
            stds=gmm_params["stds"],
            weights=gmm_params["weights"],
        )
        return categories, p_data, gmm_params
    raise ValueError(f"Unknown data_type: {args.data_type}")


def checkpoint_path(args):
    if args.save_best:
        return (
            f"{args.model_dir}/ddpm_{args.data_type}_1d_{args.num_categories}cat_"
            f"{args.num_steps}numsteps{args.save_suffix}_checkpoint_best.pth"
        )
    return (
        f"{args.model_dir}/ddpm_{args.data_type}_1d_{args.num_categories}cat_"
        f"{args.num_steps}numsteps{args.save_suffix}_checkpoint_iter_{args.n_iter}.pth"
    )


def main():
    args = dse_parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    _, p_data, gmm_params = build_target_distribution(args)
    print(f"Data type: {args.data_type}")
    print(f"Number of categories: {args.num_categories}")

    if args.mode == "training":
        train_ddpm(
            num_categories=args.num_categories,
            p_data_values=p_data,
            device=args.device,
            learning_rate=args.lr,
            num_iterations=args.n_iter,
            batch_size=args.batch_size,
            hidden_dim=args.hidden_dim,
            embed_dim=args.embed_dim,
            data_type=args.data_type,
            num_steps=args.num_steps,
            checkpoint_dir=args.model_dir,
            save_best=args.save_best,
            save_suffix=args.save_suffix,
            gmm_params=gmm_params,
        )
    elif args.mode == "inference":
        load_model(checkpoint_path(args), device=args.device)
    else:
        raise ValueError(f"Unknown mode: {args.mode}")


if __name__ == "__main__":
    main()

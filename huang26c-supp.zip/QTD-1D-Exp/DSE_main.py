"""Train or load the discrete-time QTD/DSE model."""

from configs.arg_parser import dse_parse_args
from configs.misc import set_seed
from modules.data_generation import (
    create_1d_continuous_distribution,
    create_1d_gmm_distribution,
    create_1d_true_distribution,
    get_gmm_params,
)
from modules.trainer import load_model, train_dse


def build_target_distribution(args):
    """Create the target PMF used by the QTD/DSE model."""
    if args.data_type == "discrete":
        return create_1d_true_distribution(args.num_categories)
    if args.data_type == "continuous":
        return create_1d_continuous_distribution(args.num_categories, mean=8.0, std=2.0)
    if args.data_type == "GMM":
        gmm_params = get_gmm_params()
        return create_1d_gmm_distribution(
            args.num_categories,
            means=gmm_params["means"],
            stds=gmm_params["stds"],
            weights=gmm_params["weights"],
        )
    raise ValueError(f"Unknown data_type: {args.data_type}")


def checkpoint_path(args):
    if args.save_best:
        return (
            f"{args.model_dir}/dse_{args.data_type}_1d_"
            f"{args.num_categories}cat{args.save_suffix}_checkpoint_best.pth"
        )
    return (
        f"{args.model_dir}/dse_{args.data_type}_1d_"
        f"{args.num_categories}cat{args.save_suffix}_checkpoint_iter_{args.n_iter}.pth"
    )


def main():
    args = dse_parse_args()
    set_seed(args.seed)

    _, p_data = build_target_distribution(args)
    print(f"Data type: {args.data_type}")
    print(f"Number of categories: {args.num_categories}")

    if args.mode == "training":
        train_dse(
            num_categories=args.num_categories,
            p_data_values=p_data,
            mixing_time=args.mixing_time,
            device=args.device,
            learning_rate=args.lr,
            num_iterations=args.n_iter,
            batch_size=args.batch_size,
            hidden_dim=args.hidden_dim,
            embed_dim=args.embed_dim,
            checkpoint_dir=args.model_dir,
            data_type=args.data_type,
            save_best=args.save_best,
            save_suffix=args.save_suffix,
        )
    elif args.mode == "inference":
        load_model(checkpoint_path(args), device=args.device)
    else:
        raise ValueError(f"Unknown mode: {args.mode}")


if __name__ == "__main__":
    main()

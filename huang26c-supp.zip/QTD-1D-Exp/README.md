# QTD 1D Experiments

Minimal code for reproducing the QTD vs DDPM 1D GMM experiment.

The main outputs are:

- `comparison_results/tv_vs_nfe_multi_seed.pdf`
- `comparison_results/histogram_evolution_comparison.pdf`

## Setup

Use Python 3.10-3.12 with a working PyTorch installation.

```bash
pip install -r requirements.txt
```

## Run

```bash
chmod +x run_all.sh
./run_all.sh cuda:0 GMM
```

To reuse existing checkpoints:

```bash
./run_all.sh cuda:0 GMM skip
```

To reuse existing checkpoints and trajectories:

```bash
./run_all.sh cuda:0 GMM skip skip
```

## Files

- `DSE_main.py`: train the QTD/DSE model.
- `DDPM_main.py`: train the DDPM baseline.
- `generate_and_save_trajectories.py`: generate sampling trajectories.
- `visualize_from_trajectories.py`: compute TV distance and make figures.
- `run_all.sh`: full training, sampling, and plotting pipeline.

Model code lives in `networks/`, training/data utilities in `modules/`, samplers in `samplers/`, and losses in `utils/`.

The QTD/DSE sampler uses binary bit flips, so `num_categories` should be a power of two. The default is `128`.

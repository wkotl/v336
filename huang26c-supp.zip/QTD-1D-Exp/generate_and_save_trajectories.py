"""
Phase 2: Generate and save trajectories for DSE and DDPM models.

This script:
1. Loads trained models for each target seed
2. Generates trajectories (state, NFE pairs) for both DSE and DDPM
3. Saves trajectories to disk for later visualization

Usage:
    python generate_and_save_trajectories.py --device cuda:0 --target_seeds 1 2 3 --inference_seed 1
"""
import torch
import numpy as np
import argparse
import os
import time

from configs.misc import set_seed
from modules.data_generation import (
    create_1d_true_distribution, 
    create_1d_continuous_distribution,
    create_1d_gmm_distribution,
    get_gmm_params,
    get_gmm_range
)
from modules.trainer import load_model
from samplers.trajectory_sampler import (
    dse_trajectory_sampler,
    ddpm_trajectory_sampler,
)


def get_model_path(model_type, data_type, num_categories, num_steps, num_iterations, target_seed, model_dir):
    """Get the checkpoint path for a model trained with a specific target seed."""
    suffix = f"_target{target_seed}"
    if model_type == 'dse':
        return f"{model_dir}/dse_{data_type}_1d_{num_categories}cat{suffix}_checkpoint_iter_{num_iterations}.pth"
    else:  # ddpm
        return f"{model_dir}/ddpm_{data_type}_1d_{num_categories}cat_{num_steps}numsteps{suffix}_checkpoint_iter_{num_iterations}.pth"


def get_trajectory_save_path(model_type, data_type, num_categories, num_steps, target_seed, inference_seed, save_dir):
    """Get the trajectory file path."""
    suffix = f"_target{target_seed}_infseed{inference_seed}"
    if model_type == 'dse':
        return f"{save_dir}/dse_{data_type}_1d_{num_categories}cat{suffix}_trajectories.npz"
    else:  # ddpm
        return f"{save_dir}/ddpm_{data_type}_1d_{num_categories}cat_{num_steps}numsteps{suffix}_trajectories.npz"


def main():
    parser = argparse.ArgumentParser(description="Generate and save trajectories for DSE and DDPM")
    
    # Seed configuration
    parser.add_argument("--target_seeds", type=int, nargs='+', default=[1],
                        help="Seeds for target distribution/training")
    parser.add_argument("--inference_seed", type=int, default=1,
                        help="Seed for inference/sampling randomness (ignored if --use_target_as_inference_seed)")
    parser.add_argument("--use_target_as_inference_seed", action="store_true",
                        help="Use target_seed as inference_seed for each target (different randomness per target)")
    
    # Model params
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--data_type", type=str, default="GMM", 
                        choices=["discrete", "continuous", "GMM"])
    parser.add_argument("--num_categories", type=int, default=128)
    parser.add_argument("--num_samples", type=int, default=5000)
    parser.add_argument("--batch_size", type=int, default=512)
    
    # DSE params
    parser.add_argument("--mixing_time", type=float, default=2.0)
    parser.add_argument("--delta_time", type=float, default=1e-4)
    
    # DDPM params
    parser.add_argument("--num_steps", type=int, default=1000)
    
    # Training iteration count (for loading model)
    parser.add_argument("--n_iter", type=int, default=20000)
    
    # Paths
    parser.add_argument("--model_dir", type=str, default="./model_checkpoints/")
    parser.add_argument("--save_dir", type=str, default="./trajectories/")
    
    args = parser.parse_args()
    
    os.makedirs(args.save_dir, exist_ok=True)
    
    print("="*70)
    print("Phase 2: Generate and Save Trajectories")
    print("="*70)
    print(f"Data type: {args.data_type}")
    print(f"Target seeds: {args.target_seeds}")
    if args.use_target_as_inference_seed:
        print(f"Inference seed: use target_seed for each (different randomness per target)")
    else:
        print(f"Inference seed: {args.inference_seed} (same for all targets)")
    print(f"Device: {args.device}")
    print(f"Samples per model: {args.num_samples}")
    print(f"Save directory: {args.save_dir}")
    print("="*70)
    
    for target_seed in args.target_seeds:
        # Determine inference seed for this target
        inference_seed = target_seed if args.use_target_as_inference_seed else args.inference_seed
        
        print(f"\n{'='*50}")
        print(f"Target Seed {target_seed}, Inference Seed {inference_seed}")
        print(f"{'='*50}")
        
        # Generate target distribution with this seed (for metadata)
        set_seed(target_seed)
        if args.data_type == "GMM":
            gmm_params = get_gmm_params()
            _, true_dist = create_1d_gmm_distribution(
                args.num_categories,
                means=gmm_params['means'],
                stds=gmm_params['stds'],
                weights=gmm_params['weights']
            )
            disc_x_min, disc_x_max = get_gmm_range(gmm_params['means'], gmm_params['stds'])
            disc_mean = (disc_x_min + disc_x_max) / 2
            disc_std = (disc_x_max - disc_x_min) / 6
        elif args.data_type == "continuous":
            _, true_dist = create_1d_continuous_distribution(args.num_categories, mean=8.0, std=2.0)
            disc_mean = 8.0
            disc_std = 2.0
            disc_x_min = disc_mean - 3.0 * disc_std
            disc_x_max = disc_mean + 3.0 * disc_std
        else:  # discrete
            _, true_dist = create_1d_true_distribution(args.num_categories)
            disc_mean = 8.0
            disc_std = 2.0
            disc_x_min = None
            disc_x_max = None
        
        # Get model paths
        dse_path = get_model_path('dse', args.data_type, args.num_categories, 
                                   args.num_steps, args.n_iter, target_seed, args.model_dir)
        ddpm_path = get_model_path('ddpm', args.data_type, args.num_categories, 
                                    args.num_steps, args.n_iter, target_seed, args.model_dir)
        
        # Get trajectory save paths
        dse_traj_path = get_trajectory_save_path('dse', args.data_type, args.num_categories,
                                                  args.num_steps, target_seed, inference_seed, args.save_dir)
        ddpm_traj_path = get_trajectory_save_path('ddpm', args.data_type, args.num_categories,
                                                   args.num_steps, target_seed, inference_seed, args.save_dir)
        
        # Load models
        print(f"\nLoading DSE model: {dse_path}")
        try:
            dse_model, _ = load_model(dse_path, device=args.device)
            dse_model.eval()
        except FileNotFoundError:
            print(f"ERROR: DSE model not found at {dse_path}")
            continue
        
        print(f"Loading DDPM model: {ddpm_path}")
        try:
            ddpm_model, _ = load_model(ddpm_path, device=args.device)
            ddpm_model.eval()
        except FileNotFoundError:
            print(f"ERROR: DDPM model not found at {ddpm_path}")
            continue
        
        # Set inference seed
        set_seed(inference_seed)
        
        # Generate DSE trajectories
        print(f"\nGenerating {args.num_samples} DSE trajectories...")
        start_time = time.time()
        dse_trajectories, dse_final_states = dse_trajectory_sampler(
            model=dse_model,
            num_samples=args.num_samples,
            mixing_time=args.mixing_time,
            delta_time=args.delta_time,
            num_K=args.num_categories,
            device=args.device,
            show_progress=True,
            batch_size=args.batch_size
        )
        dse_time = time.time() - start_time
        print(f"DSE sampling done in {dse_time:.1f}s")
        
        # Find DSE NFE stats
        dse_nfes = [traj[-1][1] for traj in dse_trajectories if len(traj) > 0]
        print(f"DSE NFE: min={min(dse_nfes)}, max={max(dse_nfes)}, mean={np.mean(dse_nfes):.1f}")
        
        # Generate DDPM trajectories
        print(f"\nGenerating {args.num_samples} DDPM trajectories...")
        set_seed(inference_seed)  # Reset seed for DDPM
        start_time = time.time()
        ddpm_trajectories, ddpm_final_states = ddpm_trajectory_sampler(
            model=ddpm_model,
            num_samples=args.num_samples,
            num_steps=args.num_steps,
            device=args.device,
            show_progress=True
        )
        ddpm_time = time.time() - start_time
        print(f"DDPM sampling done in {ddpm_time:.1f}s")
        
        # Save DSE trajectories
        print(f"\nSaving DSE trajectories to {dse_traj_path}")
        dse_metadata = {
            'target_seed': target_seed,
            'inference_seed': inference_seed,
            'num_samples': args.num_samples,
            'num_categories': args.num_categories,
            'data_type': args.data_type,
            'mixing_time': args.mixing_time,
            'delta_time': args.delta_time,
            'true_dist': true_dist.detach().cpu().numpy() if hasattr(true_dist, 'detach') else np.array(true_dist),
            'disc_mean': disc_mean,
            'disc_std': disc_std,
            'disc_x_min': disc_x_min if disc_x_min is not None else np.nan,
            'disc_x_max': disc_x_max if disc_x_max is not None else np.nan,
        }
        np.savez_compressed(dse_traj_path, 
                           trajectories=np.array(dse_trajectories, dtype=object),
                           final_states=np.array(dse_final_states),
                           **dse_metadata)
        
        # Save DDPM trajectories
        print(f"Saving DDPM trajectories to {ddpm_traj_path}")
        ddpm_metadata = {
            'target_seed': target_seed,
            'inference_seed': inference_seed,
            'num_samples': args.num_samples,
            'num_categories': args.num_categories,
            'data_type': args.data_type,
            'num_steps': args.num_steps,
            'true_dist': true_dist.detach().cpu().numpy() if hasattr(true_dist, 'detach') else np.array(true_dist),
            'disc_mean': disc_mean,
            'disc_std': disc_std,
            'disc_x_min': disc_x_min if disc_x_min is not None else np.nan,
            'disc_x_max': disc_x_max if disc_x_max is not None else np.nan,
        }
        ddpm_final = ddpm_final_states.cpu().numpy() if hasattr(ddpm_final_states, 'cpu') else np.array(ddpm_final_states)
        np.savez_compressed(ddpm_traj_path, 
                           trajectories=np.array(ddpm_trajectories, dtype=object),
                           final_states=ddpm_final,
                           **ddpm_metadata)
        
        print(f"Trajectories saved for target seed {target_seed}")
    
    print("\n" + "="*70)
    print("Phase 2 Complete: All trajectories generated and saved")
    print("="*70)


if __name__ == "__main__":
    main()

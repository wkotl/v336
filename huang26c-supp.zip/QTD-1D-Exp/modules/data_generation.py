"""Target distributions and forward noising processes for the experiments."""

import numpy as np
import torch
from scipy.stats import norm


def create_1d_true_distribution(num_categories=16):
    """Create the hand-written categorical target distribution."""
    x = torch.arange(num_categories)
    if num_categories == 16:
        p_data = torch.tensor(
            [
                0.02,
                0.03,
                0.01,
                0.04,
                0.08,
                0.02,
                0.12,
                0.06,
                0.10,
                0.02,
                0.13,
                0.05,
                0.06,
                0.03,
                0.08,
                0.15,
            ],
            dtype=torch.float32,
        )
    else:
        p_data = torch.ones(num_categories, dtype=torch.float32)
    p_data /= p_data.sum()
    return x, p_data


def create_1d_continuous_distribution(num_categories=128, mean=8.0, std=2.0, range_factor=3.0):
    """Discretize a Gaussian target into ``num_categories`` bins."""
    x = torch.arange(num_categories)
    x_min = mean - range_factor * std
    x_max = mean + range_factor * std
    bin_edges = np.linspace(x_min, x_max, num_categories + 1)

    p_data = []
    for i in range(num_categories):
        prob = norm.cdf(bin_edges[i + 1], mean, std) - norm.cdf(bin_edges[i], mean, std)
        p_data.append(prob)

    p_data = torch.tensor(p_data, dtype=torch.float32)
    p_data /= p_data.sum()
    return x, p_data


def generate_continuous_samples(num_samples, mean=8.0, std=2.0, device="cpu"):
    """Sample continuous data for DDPM training."""
    return torch.normal(mean=mean, std=std, size=(num_samples,), device=device)


def create_1d_gmm_distribution(num_categories=128, means=None, stds=None, weights=None, range_factor=3.0):
    """Discretize a two-component Gaussian mixture target."""
    if means is None:
        means = [-1.0, 1.0]
    if stds is None:
        stds = [1.0, 1.5]
    if weights is None:
        weights = [0.4, 0.6]

    weights = np.array(weights)
    weights = weights / weights.sum()

    x = torch.arange(num_categories)
    x_min, x_max = get_gmm_range(means, stds, range_factor=range_factor)
    bin_edges = np.linspace(x_min, x_max, num_categories + 1)

    p_data = []
    for i in range(num_categories):
        prob = 0.0
        for mean, std, weight in zip(means, stds, weights):
            prob += weight * (norm.cdf(bin_edges[i + 1], mean, std) - norm.cdf(bin_edges[i], mean, std))
        p_data.append(prob)

    p_data = torch.tensor(p_data, dtype=torch.float32)
    p_data /= p_data.sum()
    return x, p_data


def generate_gmm_samples(num_samples, means=None, stds=None, weights=None, device="cpu"):
    """Sample continuous data from the GMM target for DDPM training."""
    if means is None:
        means = [-1.0, 1.0]
    if stds is None:
        stds = [1.0, 1.5]
    if weights is None:
        weights = [0.4, 0.6]

    weights = np.array(weights)
    weights = weights / weights.sum()
    component_indices = np.random.choice(len(means), size=num_samples, p=weights)

    samples = torch.zeros(num_samples, device=device)
    for i, (mean, std) in enumerate(zip(means, stds)):
        mask = component_indices == i
        n_samples_component = mask.sum()
        if n_samples_component > 0:
            samples[mask] = torch.normal(mean=mean, std=std, size=(n_samples_component,), device=device)
    return samples


def get_gmm_params():
    """Sample separated two-component GMM parameters after the random seed is set."""
    mu1 = np.random.uniform(-1.5, -1.0)
    mu2 = np.random.uniform(1.0, 1.5)
    sigma1 = np.random.uniform(0.4, 1.0)
    sigma2 = np.random.uniform(0.4, 1.0)
    w1 = np.random.uniform(0.3, 0.7)
    return {
        "means": [mu1, mu2],
        "stds": [sigma1, sigma2],
        "weights": [w1, 1.0 - w1],
    }


def get_gmm_range(means=None, stds=None, range_factor=3.0):
    """Get the discretization range used for the GMM target."""
    if means is None:
        means = [-1.0, 1.0]
    if stds is None:
        stds = [1.0, 1.5]
    x_min = min(means) - range_factor * max(stds)
    x_max = max(means) + range_factor * max(stds)
    return x_min, x_max


def generate_1d_data_time_pairs(p_data, mixing_time, batch_size, device="cpu"):
    """Sample clean categorical data and continuous noising times for QTD/DSE."""
    sample_idx = torch.multinomial(p_data.to(device), batch_size, replacement=True)
    sample_time = torch.rand(batch_size, device=device) * mixing_time
    return sample_idx, sample_time


def generate_1d_data_in_fwd_path(x_0, timestamps, num_categories, batch_size, device):
    """Apply the binary bit-flip CTMC forward process to categorical data."""
    temp_dim = int(num_categories - 1).bit_length()
    flip_sample = torch.rand(batch_size, temp_dim, device=device)
    flip_prob = (1 - torch.exp(-2 * timestamps)) / 2.0
    flip_sign = (flip_sample < flip_prob.view(-1, 1)).int()
    bin_powers = 2 ** torch.arange(temp_dim - 1, -1, -1, dtype=torch.int64, device=device)
    flip_num = (flip_sign * bin_powers).sum(dim=1).long()
    return x_0 ^ flip_num


def ddpm_add_noise_discrete(x_0, timesteps, num_steps, device="cpu"):
    """Apply the standard DDPM Gaussian forward noising process."""
    beta_start = 0.0001
    beta_end = 0.02
    betas = torch.linspace(beta_start, beta_end, num_steps, device=device)
    alphas = 1.0 - betas
    alpha_bar = torch.cumprod(alphas, dim=0)
    alpha_bar_t = alpha_bar[timesteps]

    noise = torch.randn_like(x_0, device=device)
    x_t = torch.sqrt(alpha_bar_t) * x_0 + torch.sqrt(1.0 - alpha_bar_t) * noise
    return x_t, noise, alpha_bar_t

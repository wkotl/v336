"""Training and checkpoint utilities for QTD/DSE and DDPM."""

import os

import torch
import torch.optim as optim
from tqdm import trange

from modules.data_generation import (
    ddpm_add_noise_discrete,
    generate_1d_data_in_fwd_path,
    generate_1d_data_time_pairs,
    generate_continuous_samples,
    generate_gmm_samples,
    get_gmm_params,
)
from networks.networks import DDPMNet, DenoiseScoreNet
from utils.losses import ddpm_loss, dse_loss_cycle


def train_dse(
    num_categories,
    p_data_values,
    mixing_time,
    device,
    learning_rate,
    num_iterations,
    batch_size,
    hidden_dim,
    embed_dim,
    data_type,
    checkpoint_dir=None,
    save_best=False,
    save_suffix="",
):
    """Train the QTD/DSE model on a discretized target distribution."""
    model = DenoiseScoreNet(num_categories, embed_dim, hidden_dim).to(device)
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    model.train()
    train_losses = []
    best_loss = float("inf")
    best_model_state = None
    best_iteration = 0

    for iteration in trange(num_iterations, desc="Training QTD/DSE"):
        optimizer.zero_grad()
        x_0, timestamps = generate_1d_data_time_pairs(p_data_values, mixing_time, batch_size, device)
        x_t = generate_1d_data_in_fwd_path(x_0, timestamps, num_categories, batch_size, device)

        ln_score_at_x_t = model(x_t, timestamps)
        score_at_x_t = torch.exp(ln_score_at_x_t)
        loss = dse_loss_cycle(x_0, timestamps, x_t, score_at_x_t, num_categories, device)
        loss.backward()
        optimizer.step()

        train_losses.append(loss.item())
        if loss.item() < best_loss:
            best_loss = loss.item()
            best_model_state = {k: v.clone() for k, v in model.state_dict().items()}
            best_iteration = iteration

        if (iteration + 1) % 1000 == 0:
            print(
                f"[Iteration {iteration + 1}/{num_iterations}]: "
                f"Current Loss {loss.item():.4f}, Best Loss {best_loss:.4f} "
                f"(iter {best_iteration + 1})"
            )

    if save_best:
        model.load_state_dict(best_model_state)

    save_model(
        model_type="dse",
        data_type=data_type,
        model=model,
        optimizer=optimizer,
        checkpoint_dir=checkpoint_dir,
        save_best=save_best,
        num_iterations=num_iterations,
        best_loss=best_loss,
        final_loss=loss.item(),
        train_losses=train_losses,
        best_iteration=best_iteration,
        num_categories=num_categories,
        p_data_values=p_data_values,
        embed_dim=embed_dim,
        hidden_dim=hidden_dim,
        save_suffix=save_suffix,
    )
    return model, train_losses


def train_ddpm(
    num_categories,
    p_data_values,
    device,
    learning_rate,
    num_iterations,
    batch_size,
    hidden_dim,
    embed_dim,
    data_type,
    num_steps=1000,
    checkpoint_dir=None,
    save_best=False,
    save_suffix="",
    gmm_params=None,
):
    """Train the continuous DDPM baseline."""
    model = DDPMNet(hidden_dim=hidden_dim).to(device)
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    model.train()
    train_losses = []
    best_loss = float("inf")
    best_model_state = None
    best_iteration = 0

    if data_type == "GMM" and gmm_params is None:
        gmm_params = get_gmm_params()

    for iteration in trange(num_iterations, desc=f"Training DDPM (num_steps={num_steps})"):
        optimizer.zero_grad()
        if data_type == "GMM":
            x_0 = generate_gmm_samples(
                batch_size,
                means=gmm_params["means"],
                stds=gmm_params["stds"],
                weights=gmm_params["weights"],
                device=device,
            )
        else:
            x_0 = generate_continuous_samples(batch_size, mean=8.0, std=2.0, device=device)

        timesteps = torch.randint(0, num_steps, (batch_size,), device=device)
        x_t, noise, _ = ddpm_add_noise_discrete(x_0, timesteps, num_steps, device=device)
        predicted_noise = model(x_t, timesteps)
        loss = ddpm_loss(predicted_noise, noise)
        loss.backward()
        optimizer.step()

        train_losses.append(loss.item())
        if loss.item() < best_loss:
            best_loss = loss.item()
            best_model_state = {k: v.clone() for k, v in model.state_dict().items()}
            best_iteration = iteration

        if (iteration + 1) % 1000 == 0:
            print(
                f"[Iteration {iteration + 1}/{num_iterations}]: "
                f"Current Loss {loss.item():.4f}, Best Loss {best_loss:.4f} "
                f"(iter {best_iteration + 1})"
            )

    if save_best:
        model.load_state_dict(best_model_state)

    save_model(
        model_type="ddpm",
        data_type=data_type,
        model=model,
        optimizer=optimizer,
        checkpoint_dir=checkpoint_dir,
        save_best=save_best,
        num_iterations=num_iterations,
        best_loss=best_loss,
        final_loss=loss.item(),
        train_losses=train_losses,
        best_iteration=best_iteration,
        num_categories=num_categories,
        p_data_values=p_data_values,
        embed_dim=embed_dim,
        hidden_dim=hidden_dim,
        num_steps=num_steps,
        save_suffix=save_suffix,
    )
    return model, train_losses


def save_model(
    model_type,
    data_type,
    model,
    optimizer,
    checkpoint_dir,
    save_best,
    num_iterations,
    best_loss,
    final_loss,
    train_losses,
    best_iteration,
    **checkpoint_data,
):
    """Save a training checkpoint."""
    os.makedirs(checkpoint_dir, exist_ok=True)
    num_categories = checkpoint_data["num_categories"]
    save_suffix = checkpoint_data.get("save_suffix", "")

    if model_type == "ddpm":
        num_steps = checkpoint_data["num_steps"]
        stem = f"{model_type}_{data_type}_1d_{num_categories}cat_{num_steps}numsteps{save_suffix}"
    else:
        stem = f"{model_type}_{data_type}_1d_{num_categories}cat{save_suffix}"

    filename = f"{stem}_checkpoint_best.pth" if save_best else f"{stem}_checkpoint_iter_{num_iterations}.pth"
    iteration = best_iteration if save_best else num_iterations - 1
    checkpoint_path = os.path.join(checkpoint_dir, filename)
    checkpoint = {
        "iteration": iteration,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "best_loss": best_loss,
        "best_iteration": best_iteration,
        "final_loss": final_loss,
        "train_losses": train_losses,
        "num_iterations": num_iterations,
        **checkpoint_data,
    }
    torch.save(checkpoint, checkpoint_path)
    print(f"Saved {model_type.upper()} checkpoint to {checkpoint_path}")


def load_model(checkpoint_path, device="cpu"):
    """Load a QTD/DSE or DDPM checkpoint."""
    checkpoint = torch.load(checkpoint_path, map_location=device)
    num_categories = checkpoint["num_categories"]
    embed_dim = checkpoint.get("embed_dim", 10)
    hidden_dim = checkpoint.get("hidden_dim", 40)

    if "ddpm_" in checkpoint_path:
        model = DDPMNet(hidden_dim=hidden_dim).to(device)
        model_type = "DDPM"
    elif "dse_" in checkpoint_path:
        model = DenoiseScoreNet(num_categories, embed_dim, hidden_dim).to(device)
        model_type = "QTD/DSE"
    else:
        raise ValueError(f"Cannot infer model type from checkpoint path: {checkpoint_path}")

    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    print(f"Loaded {model_type} model from {checkpoint_path}")
    print(f"Training iteration: {checkpoint['iteration'] + 1}")
    if checkpoint.get("train_losses"):
        print(f"Final training loss: {checkpoint['train_losses'][-1]:.4f}")
    return model, checkpoint

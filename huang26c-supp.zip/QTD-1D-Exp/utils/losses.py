"""Loss functions for QTD/DSE and DDPM."""

import torch


def dse_loss_cycle(x_0, timestamps, x_t, model_scores_at_x_t, num_categories, device):
    """Denoising score entropy loss for the binary bit-flip CTMC."""
    temp_dim = int(num_categories - 1).bit_length()
    temp_power = 2 ** torch.arange(temp_dim - 1, -1, -1, dtype=torch.int64, device=device)

    x_t_sign = x_t.unsqueeze(-1) & temp_power
    x_0_sign = x_0.unsqueeze(-1) & temp_power
    prob_sign = torch.where(
        x_t_sign == x_0_sign,
        torch.ones((), dtype=torch.int64, device=device),
        torch.full((), -1, dtype=torch.int64, device=device),
    )
    basic_ratio = (1 - torch.exp(-2 * timestamps)) / (1 + torch.exp(-2 * timestamps))
    fwd_conditional_ratio = basic_ratio.unsqueeze(1) ** prob_sign.float()
    loss_finite_sum = model_scores_at_x_t - fwd_conditional_ratio * torch.log(model_scores_at_x_t)
    return loss_finite_sum.sum()


def ddpm_loss(predicted_noise, true_noise):
    """Mean-squared error for DDPM noise prediction."""
    return torch.nn.functional.mse_loss(predicted_noise, true_noise)

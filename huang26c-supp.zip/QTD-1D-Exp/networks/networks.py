"""Neural network architectures used in the QTD and DDPM experiments."""

import torch
import torch.nn as nn


class DenoiseScoreNet(nn.Module):
    """QTD/DSE score network over binary bit flips."""

    def __init__(self, num_categories, embed_dim=10, hidden_dim=40):
        super().__init__()
        self.num_categories = num_categories
        self.vocab = nn.Parameter(torch.empty(num_categories, embed_dim))
        output_dim = int(num_categories - 1).bit_length()

        self.network = nn.Sequential(
            nn.Linear(embed_dim + 1, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )
        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.vocab, gain=nn.init.calculate_gain("tanh"))
        for layer in self.network:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight, gain=nn.init.calculate_gain("tanh"))
                nn.init.zeros_(layer.bias)

    def forward(self, x_t, timestamps):
        timestamps = timestamps.unsqueeze(1)
        embed_vecs = self.vocab[x_t]
        final_input = torch.cat([embed_vecs, timestamps], dim=1)
        return self.network(final_input)


class DDPMNet(nn.Module):
    """Continuous 1D DDPM network that predicts Gaussian noise."""

    def __init__(self, hidden_dim=64, time_embed_dim=16):
        super().__init__()
        self.time_embed_dim = time_embed_dim
        self.network = nn.Sequential(
            nn.Linear(1 + time_embed_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        self._init_weights()

    def _init_weights(self):
        for layer in self.network:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight, gain=nn.init.calculate_gain("relu"))
                nn.init.zeros_(layer.bias)

    def get_sinusoidal_embeddings(self, timesteps):
        half_dim = self.time_embed_dim // 2
        scale = torch.log(torch.tensor(10000.0, device=timesteps.device)) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=timesteps.device) * -scale)
        embeddings = timesteps.float().unsqueeze(-1) * embeddings.unsqueeze(0)
        embeddings = torch.cat([torch.sin(embeddings), torch.cos(embeddings)], dim=-1)
        if self.time_embed_dim % 2 == 1:
            embeddings = torch.cat([embeddings, torch.zeros_like(embeddings[:, :1])], dim=-1)
        return embeddings

    def forward(self, x_t, timesteps):
        time_embeddings = self.get_sinusoidal_embeddings(timesteps)
        x_t = x_t.unsqueeze(-1)
        input_features = torch.cat([x_t, time_embeddings], dim=-1)
        return self.network(input_features).squeeze(-1)

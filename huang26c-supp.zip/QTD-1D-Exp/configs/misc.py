"""
    Miscellaneous functions for settings
"""

import torch
import numpy as np


def set_seed(seed_value = 42):
    """Sets the seed for reproducibility."""
    np.random.seed(seed_value)  # Numpy module
    torch.manual_seed(seed_value)  # PyTorch CPU
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed_value)  # PyTorch all GPUs
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

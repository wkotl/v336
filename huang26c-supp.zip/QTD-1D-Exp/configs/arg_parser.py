"""Command-line arguments shared by the QTD and DDPM experiments."""

import argparse
import sys


def dse_parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--device", type=str, default="cpu", help="Device, e.g. cpu or cuda:0")
    parser.add_argument("--mode", type=str, default="training", choices=["training", "inference"])
    parser.add_argument("--data_type", type=str, default="GMM", choices=["discrete", "continuous", "GMM"])
    parser.add_argument("--num_categories", type=int, default=128)

    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--n_iter", type=int, default=100000)
    parser.add_argument("--hidden_dim", type=int, default=40)
    parser.add_argument("--embed_dim", type=int, default=10)

    parser.add_argument("--mixing_time", type=float, default=2.0, help="Maximum CTMC diffusion time")
    parser.add_argument("--num_steps", type=int, default=1000, help="Number of DDPM denoising steps")

    parser.add_argument("--model_dir", type=str, default="./model_checkpoints/")
    parser.add_argument("--save_suffix", type=str, default="")
    parser.add_argument("--save_best", action="store_true")

    if "ipykernel_launcher" in sys.argv[0] or "colab_kernel_launcher" in sys.argv[0]:
        return parser.parse_args([])
    return parser.parse_args()

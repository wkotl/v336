#!/bin/bash
#
# Complete experiment script: train all models, generate trajectories, and visualize
#
# Pipeline Structure:
#   Phase 1: Training
#     - Train DSE and DDPM models for each target seed
#     - Save model checkpoints
#
#   Phase 2: Trajectory Generation
#     - Load trained models
#     - Generate trajectories (state, NFE pairs) for both DSE and DDPM
#     - Save trajectories to disk
#
#   Phase 3: Visualization
#     - Load saved trajectories
#     - Plot TV vs NFE (with custom NFE grids: DSE focuses on 0-100, DDPM on 500-1000)
#     - Plot histogram evolution comparison
#
# Usage:
#   chmod +x run_all.sh
#   ./run_all.sh                           # Use default GPU (cuda:0), data_type=GMM
#   ./run_all.sh cuda:1                    # Use specific GPU
#   ./run_all.sh cuda:0 continuous         # Specify data type (continuous, GMM, or discrete)
#   ./run_all.sh cuda:0 GMM skip           # Skip training, only run Phase 2 and 3
#   ./run_all.sh cuda:0 GMM skip skip      # Skip training and trajectory generation, only run Phase 3

set -e  # Exit on error

# Configuration
DEVICE=${1:-cuda:0}
DATA_TYPE=${2:-GMM}
SKIP_TRAIN=${3:-}
SKIP_TRAJ=${4:-}

# Seeds configuration
TARGET_SEEDS=(1 2 3 4 5 6 7 8 9 10)
# Each target seed uses itself as inference seed (different randomness per target)
USE_TARGET_AS_INFERENCE_SEED=true

# Training parameters
N_ITER=20000
NUM_CATEGORIES=128
NUM_STEPS=1000

# Sampling parameters
NUM_SAMPLES=5000
BATCH_SIZE=512

# Directories
MODEL_DIR="./model_checkpoints"
TRAJ_DIR="./trajectories"
RESULT_DIR="./comparison_results"

echo "========================================"
echo "DSE vs DDPM Full Experiment Pipeline"
echo "========================================"
echo "Device: $DEVICE"
echo "Data type: $DATA_TYPE"
echo "Target seeds: ${TARGET_SEEDS[@]}"
echo "Inference seed: use target_seed for each (different randomness per target)"
echo "Training iterations: $N_ITER"
echo "Number of categories: $NUM_CATEGORIES"
echo "Number of samples: $NUM_SAMPLES"
echo "========================================"
echo ""

# Create directories
mkdir -p $MODEL_DIR
mkdir -p $TRAJ_DIR
mkdir -p $RESULT_DIR

# ==========================================
# PHASE 1: Training
# ==========================================
if [ "$SKIP_TRAIN" != "skip" ]; then
    echo "========================================"
    echo "PHASE 1: Training Models"
    echo "========================================"
    echo "Will train ${#TARGET_SEEDS[@]} × 2 = $((${#TARGET_SEEDS[@]} * 2)) models"
    echo ""

    for TARGET_SEED in "${TARGET_SEEDS[@]}"; do
        echo "----------------------------------------"
        echo "Training with target seed: $TARGET_SEED"
        echo "----------------------------------------"
        
        # Check if DSE checkpoint exists
        DSE_CKPT="${MODEL_DIR}/dse_${DATA_TYPE}_1d_${NUM_CATEGORIES}cat_target${TARGET_SEED}_checkpoint_iter_${N_ITER}.pth"
        if [ -f "$DSE_CKPT" ]; then
            echo "[DSE] Checkpoint already exists, skipping: $DSE_CKPT"
        else
            echo "[DSE] Training with target seed $TARGET_SEED..."
            python DSE_main.py \
                --seed $TARGET_SEED \
                --device $DEVICE \
                --mode training \
                --data_type $DATA_TYPE \
                --num_categories $NUM_CATEGORIES \
                --n_iter $N_ITER \
                --save_suffix "_target${TARGET_SEED}"
            echo "[DSE] Done training with target seed $TARGET_SEED"
        fi
        echo ""
        
        # Check if DDPM checkpoint exists
        DDPM_CKPT="${MODEL_DIR}/ddpm_${DATA_TYPE}_1d_${NUM_CATEGORIES}cat_${NUM_STEPS}numsteps_target${TARGET_SEED}_checkpoint_iter_${N_ITER}.pth"
        if [ -f "$DDPM_CKPT" ]; then
            echo "[DDPM] Checkpoint already exists, skipping: $DDPM_CKPT"
        else
            echo "[DDPM] Training with target seed $TARGET_SEED..."
            python DDPM_main.py \
                --seed $TARGET_SEED \
                --device $DEVICE \
                --mode training \
                --data_type $DATA_TYPE \
                --num_categories $NUM_CATEGORIES \
                --n_iter $N_ITER \
                --num_steps $NUM_STEPS \
                --save_suffix "_target${TARGET_SEED}"
            echo "[DDPM] Done training with target seed $TARGET_SEED"
        fi
        echo ""
    done

    echo ""
    echo "========================================"
    echo "PHASE 1 Complete: All models trained"
    echo "========================================"
    echo ""
else
    echo "Skipping Phase 1 (training)"
    echo ""
fi

# ==========================================
# PHASE 2: Trajectory Generation
# ==========================================
if [ "$SKIP_TRAJ" != "skip" ]; then
    echo "========================================"
    echo "PHASE 2: Generating Trajectories"
    echo "========================================"
    echo "Will generate trajectories for ${#TARGET_SEEDS[@]} target seeds"
    echo ""

    python generate_and_save_trajectories.py \
        --device $DEVICE \
        --data_type $DATA_TYPE \
        --target_seeds ${TARGET_SEEDS[@]} \
        --use_target_as_inference_seed \
        --num_samples $NUM_SAMPLES \
        --batch_size $BATCH_SIZE \
        --n_iter $N_ITER \
        --num_steps $NUM_STEPS \
        --model_dir $MODEL_DIR \
        --save_dir $TRAJ_DIR

    echo ""
    echo "========================================"
    echo "PHASE 2 Complete: Trajectories saved to $TRAJ_DIR"
    echo "========================================"
    echo ""
else
    echo "Skipping Phase 2 (trajectory generation)"
    echo ""
fi

# ==========================================
# PHASE 3: Visualization
# ==========================================
echo "========================================"
echo "PHASE 3: Visualization"
echo "========================================"

python visualize_from_trajectories.py \
    --data_type $DATA_TYPE \
    --target_seeds ${TARGET_SEEDS[@]} \
    --use_target_as_inference_seed \
    --num_steps $NUM_STEPS \
    --traj_dir $TRAJ_DIR \
    --save_dir $RESULT_DIR \
    --dse_hist_checkpoints 0 30 40 50 60 80 100 \
    --ddpm_hist_checkpoints 0 100 500 600 700 800 900 1000

echo ""
echo "========================================"
echo "Experiment Complete!"
echo "========================================"
echo ""
echo "Results saved to: $RESULT_DIR/"
echo "  - tv_vs_nfe_multi_seed.pdf           (TV distance vs NFE)"
echo "  - histogram_evolution_comparison.pdf (histogram evolution comparison)"
echo "  - tv_vs_nfe_multi_seed.npz           (numerical TV/NFE results)"
echo ""
echo "Trajectories saved to: $TRAJ_DIR/"
echo "========================================"

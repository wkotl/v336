#!/bin/bash
# =============================================================================
# Experiment 2: Discrete Diffusion small MNIST (mnist_small + multiflip)
# Steps: train 5 seeds → combined loss plot → FID (10k, multiflip) → 50 samples
# =============================================================================
set -e

BASE="/workspace/Truncated_Uniformization/mnist_small_tasks"
SEEDS=(42 123 456 789 1024)
OUT_ROOT="$BASE/results_small"
CKPT_ROOT="$BASE/checkpoints_small"

# -----------------------------------------------------------------------------
# 1. Train each seed
# -----------------------------------------------------------------------------
echo "========================================"
echo " PHASE 1: Training (5 seeds)"
echo "========================================"

for SEED in "${SEEDS[@]}"; do
    echo ""
    echo "--- Training seed=$SEED ---"
    python -m mnist_small_tasks.mnist_small_train \
        seed=$SEED \
        "output.results_dir=$OUT_ROOT/seed_$SEED" \
        "output.checkpoint_dir=$CKPT_ROOT/seed_$SEED"
done

# -----------------------------------------------------------------------------
# 2. Combined loss plot
# -----------------------------------------------------------------------------
echo ""
echo "========================================"
echo " PHASE 2: Combined loss plot"
echo "========================================"

DIRS=()
SEED_LABELS=()
for SEED in "${SEEDS[@]}"; do
    DIRS+=("$OUT_ROOT/seed_$SEED")
    SEED_LABELS+=("$SEED")
done

python -m mnist_small_tasks.plot_loss_curves \
    --dirs  "${DIRS[@]}" \
    --seeds "${SEED_LABELS[@]}" \
    --title "MNIST Training Loss" \
    --output "$OUT_ROOT/combined_training_loss.png"

# -----------------------------------------------------------------------------
# 3. FID evaluation with multiflip denoiser (10 000 samples each)
# -----------------------------------------------------------------------------
echo ""
echo "========================================"
echo " PHASE 3: FID evaluation (10k samples, multiflip)"
echo "========================================"

for SEED in "${SEEDS[@]}"; do
    echo ""
    echo "--- FID seed=$SEED ---"
    python -m mnist_small_tasks.mnist_small_fid \
        --config-name mnist_small_multiflip \
        seed=$SEED \
        "output.results_dir=$OUT_ROOT/seed_$SEED" \
        "output.checkpoint_dir=$CKPT_ROOT/seed_$SEED" \
        "fid.num_samples=10000"
done

# Summarise FID scores
echo ""
echo "--- FID summary ---"
for SEED in "${SEEDS[@]}"; do
    FID_FILE="$OUT_ROOT/seed_$SEED/fid_score.txt"
    if [ -f "$FID_FILE" ]; then
        LAST=$(grep -v "^#" "$FID_FILE" | tail -1 | awk '{print $2}')
        echo "  seed $SEED : FID = $LAST"
    fi
done

# -----------------------------------------------------------------------------
# 4. Generate 50 images per seed (case study) using multiflip sampler
# -----------------------------------------------------------------------------
echo ""
echo "========================================"
echo " PHASE 4: Sample 50 images (case study)"
echo "========================================"

for SEED in "${SEEDS[@]}"; do
    echo ""
    echo "--- Sampling seed=$SEED ---"
    python -m mnist_small_tasks.mnist_small_sample_multiflip \
        --config-name mnist_small_multiflip \
        seed=$SEED \
        "output.results_dir=$OUT_ROOT/seed_$SEED" \
        "output.checkpoint_dir=$CKPT_ROOT/seed_$SEED" \
        "sampling.batch_size=50"
done

echo ""
echo "========================================"
echo " Small MNIST experiment complete."
echo " Results: $OUT_ROOT"
echo "========================================"

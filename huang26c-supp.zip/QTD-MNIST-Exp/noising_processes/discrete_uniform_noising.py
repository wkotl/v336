"""Discrete uniform forward (noising) process."""

import torch

from noising_processes import NoisingProcess, register_noising_process


@register_noising_process(name="discrete_uniform")
class DiscreteUniformNoisingProcess(NoisingProcess):
    """The discrete uniform forward process.

    At t=start_time each token stays fixed; as t grows toward mixing_time
    the marginal distribution converges to Uniform({0, ..., vocab_size - 1}).
    """

    def __init__(self, start_time: float, mixing_time: float, vocab_size: int):
        if vocab_size <= 1:
            raise ValueError(f"vocab_size must be > 1, got {vocab_size}")
        if mixing_time <= start_time:
            raise ValueError(
                f"mixing_time must be > start_time, "
                f"got mixing_time={mixing_time}, start_time={start_time}"
            )
        super().__init__(start_time, mixing_time)
        self.vocab_size = int(vocab_size)

    def add_noise(self, x: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        """Add noise to the clean state.

        Args:
            x: Clean discrete tensor, shape [batch, ...] with integer values in
                {0, ..., vocab_size - 1}.
            t: Time tensor, shape [batch]. Each t[b] should be in
                [self.start_time, self.mixing_time].

        Returns:
            Noisy discrete tensor with the same shape as x.
        """
        # Sample a candidate replacement token != x for each element.
        potential_samples = torch.randint(
            0, self.vocab_size - 1, x.shape, device=x.device
        )
        potential_next_states = potential_samples + (potential_samples >= x).to(
            potential_samples.dtype
        )

        # Probability of staying at the current token.
        prob_stay = 1.0 / self.vocab_size + (1.0 - 1.0 / self.vocab_size) * torch.exp(
            -self.vocab_size * t.to(x.device)
        )
        # Broadcast [batch] -> [batch, 1, 1, ...] to match x's shape.
        prob_stay = prob_stay.view(-1, *([1] * (x.dim() - 1))).expand_as(x)

        stay_mask = torch.rand(x.shape, device=x.device) < prob_stay
        return torch.where(stay_mask, x, potential_next_states)

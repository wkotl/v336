"""Base class and registry for noising processes."""

import abc
from typing import Sequence

import torch

_NOISING_PROCESSES = {}


def register_noising_process(cls=None, *, name=None):
    """Decorator to register a noising process class.

    Usage:
        @register_noising_process(name="my_process")
        class MyNoisingProcess(NoisingProcess):
            ...

        # or with default name (class name):
        @register_noising_process
        class MyNoisingProcess(NoisingProcess):
            ...
    """

    def _register(cls):
        local_name = name if name is not None else cls.__name__
        if local_name in _NOISING_PROCESSES:
            raise ValueError(
                f"Already registered noising process with name: {local_name}"
            )
        _NOISING_PROCESSES[local_name] = cls
        return cls

    if cls is None:
        return _register
    return _register(cls)


def get_noising_process(name: str):
    """Return the registered noising process class by name."""
    if name not in _NOISING_PROCESSES:
        raise KeyError(
            f"Unknown noising process: {name}. "
            f"Available: {list(_NOISING_PROCESSES.keys())}"
        )
    return _NOISING_PROCESSES[name]


def list_noising_processes():
    """Return names of all registered noising processes."""
    return list(_NOISING_PROCESSES.keys())


class NoisingProcess(abc.ABC):
    """Abstract base class for a noising (forward) process."""

    def __init__(
        self,
        start_time: float,
        mixing_time: float
    ):
        super().__init__()
        self.start_time = start_time
        self.mixing_time = mixing_time

    @abc.abstractmethod
    def add_noise(self, x: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        """Add noise to the state.

        Args:
            x: State tensor, shape [batch, ...].
            t: Time tensor, shape [batch].

        Returns:
            Noisy state with same shape as x, shape [batch, ...].
        """
        pass

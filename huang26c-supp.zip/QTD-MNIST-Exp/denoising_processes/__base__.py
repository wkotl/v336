"""Base class and registry for denoising processes."""

import abc

import torch

_DENOISING_PROCESSES = {}


def register_denoising_process(cls=None, *, name=None):
    """Decorator to register a denoising process class.

    Usage:
        @register_denoising_process(name="my_process")
        class MyDenoisingProcess(DenoisingProcess):
            ...

        # or with default name (class name):
        @register_denoising_process
        class MyDenoisingProcess(DenoisingProcess):
            ...
    """

    def _register(cls):
        local_name = name if name is not None else cls.__name__
        if local_name in _DENOISING_PROCESSES:
            raise ValueError(
                f"Already registered denoising process with name: {local_name}"
            )
        _DENOISING_PROCESSES[local_name] = cls
        return cls

    if cls is None:
        return _register
    return _register(cls)


def get_denoising_process(name: str):
    """Return the registered denoising process class by name."""
    if name not in _DENOISING_PROCESSES:
        raise KeyError(
            f"Unknown denoising process: {name}. "
            f"Available: {list(_DENOISING_PROCESSES.keys())}"
        )
    return _DENOISING_PROCESSES[name]


def list_denoising_processes():
    """Return names of all registered denoising processes."""
    return list(_DENOISING_PROCESSES.keys())


class DenoisingProcess(abc.ABC):
    """Abstract base class for a denoising (reverse) process."""

    def __init__(
        self,
        batch_size: int,
        start_time: float,
        mixing_time: float,
        particle_shape: tuple,
        device: torch.device,
    ):
        super().__init__()
        self.batch_size = batch_size
        self.start_time = start_time
        self.mixing_time = mixing_time
        self.particle_shape = particle_shape
        self.device = device

    @abc.abstractmethod
    def denoise(self) -> torch.Tensor:
        """Run the full reverse process and return generated particles.

        Returns:
            Integer tensor of shape ``[batch_size, *particle_shape]``.
        """
        pass

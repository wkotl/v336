"""Discrete uniform denoising process via Truncated Uniformization."""

import torch
from tqdm import tqdm

from denoising_processes import DenoisingProcess, register_denoising_process


@register_denoising_process(name="discrete_uniform")
class TruncatedUniformizationUniform(DenoisingProcess):
    """Denoising process corresponding to the discrete uniform noising process.

    Implements the Truncated Uniformization sampler: samples a Poisson number
    of jump events in each time interval, evaluates the score network at each
    event, and applies a thinning step to accept or reject each proposed move.

    Args:
        batch_size: Number of particles to generate in parallel.
        start_time: Start time of the reverse process.
        mixing_time: End time of the reverse process (corresponds to t=0 of
            the noising process).
        particle_shape: Shape of each particle, e.g. ``(H, W)``.
        device: Torch device on which tensors are allocated.
        vocab_size: Number of discrete states per dimension.
        discrete_scores: Callable ``(x, t) -> scores`` where ``x`` has shape
            ``[batch, *particle_shape]``, ``t`` has shape ``[batch]``, and
            ``scores`` has shape ``[batch, *particle_shape, vocab_size]``.
        early_stopping: Stop iterating when the remaining time is below this
            threshold (default ``1e-3``).
    """

    def __init__(
        self,
        batch_size: int,
        start_time: float,
        mixing_time: float,
        particle_shape: tuple,
        device: torch.device,
        vocab_size: int,
        discrete_scores=None,
        early_stopping: float = 1e-3,
    ):
        super().__init__(batch_size, start_time, mixing_time, particle_shape, device)
        self.vocab_size = vocab_size
        self.discrete_scores = discrete_scores
        self.early_stopping = early_stopping

        # Number of dimensions per particle (flattened).
        self.particle_dim = int(
            torch.tensor(self.particle_shape, dtype=torch.float32).prod().item()
        )

        # Uniform sampler for the initial (fully noised) state.
        self.initial_sampler = lambda: torch.randint(
            0,
            self.vocab_size,
            (self.batch_size, *self.particle_shape),
            device=self.device,
        )

        # Build time-interval endpoints by iterating geometric interpolation.
        t = self.start_time
        endpoints = []
        while True:
            endpoints.append(t)
            if t > self.mixing_time - self.early_stopping:
                break
            t = (2.0 / 3.0) * t + (1.0 / 3.0) * self.mixing_time
        self.time_endpoints = torch.tensor(
            endpoints, device=self.device, dtype=torch.float32
        )

        # Upper bound on the jump rate in each interval (used for thinning).
        denom = self.vocab_size * (self.mixing_time - self.time_endpoints)
        self.beta = self.vocab_size * (self.particle_dim + self.particle_dim / denom)
        self.W = len(self.time_endpoints) - 1

    def denoise(self) -> torch.Tensor:
        """Run the full reverse process and return generated particles.

        Returns:
            Integer tensor of shape ``[batch_size, *particle_shape]``.
        """
        ret_particles = self.initial_sampler()

        # Sample the number of jump events per interval per particle.
        lambda_w = self.beta[1:] * (self.time_endpoints[1:] - self.time_endpoints[:-1])
        poisson_mean = lambda_w.unsqueeze(0).expand(self.batch_size, self.W)
        inner_iteration_num = torch.poisson(poisson_mean).to(torch.long)  # [batch, W]

        total_per_sample = inner_iteration_num.sum(dim=1)        # [batch]
        max_events = int(total_per_sample.max().item())          # scalar
        avg_iters = float(total_per_sample.float().mean().item())
        print(f"  [TU] Avg iterations per sample: {avg_iters:.1f}  "
              f"(min={total_per_sample.min().item()}, max={max_events})")

        # Pre-allocate buffers for event timestamps and their interval indices.
        sampled_timestamps = torch.empty(
            self.batch_size, max_events, device=self.device, dtype=torch.float32
        )
        sampled_interval = torch.empty(
            self.batch_size, max_events, device=self.device, dtype=torch.int32
        )

        for b in range(self.batch_size):
            offset = 0
            for w in range(self.W):
                n = inner_iteration_num[b, w].item()
                if n > 0:
                    low = self.time_endpoints[w]
                    high = self.time_endpoints[w + 1]
                    s = torch.rand(n, device=self.device) * (high - low) + low
                    sampled_timestamps[b, offset : offset + n] = s
                    sampled_interval[b, offset : offset + n] = w
                offset += n
            # Pad unused positions with mixing_time so they are filtered out.
            sampled_timestamps[b, offset:] = self.mixing_time

        sampled_timestamps, _ = torch.sort(sampled_timestamps, dim=1)

        for n in tqdm(range(max_events), desc="Inference", unit="step"):
            current_timestamps = sampled_timestamps[:, n]   # [batch]
            current_interval = sampled_interval[:, n]        # [batch]

            # Skip events at or past the early-stopping threshold.
            update_indices = (
                current_timestamps < self.mixing_time - self.early_stopping / 2.0
            ).nonzero(as_tuple=True)[0]
            num_updates = update_indices.size(0)

            selected_particles = ret_particles[update_indices]  # [num_updates, *particle_shape]

            # Query the score network at the mirrored (forward-time) timestamp.
            mirrored_timestamps = self.mixing_time - current_timestamps[update_indices]
            current_scores = self.discrete_scores(
                selected_particles, mirrored_timestamps
            )  # [num_updates, *particle_shape, vocab_size]

            scores_flat = current_scores.reshape(
                num_updates, self.particle_dim, self.vocab_size
            )  # [num_updates, dim, vocab_size]
            particle_flat = selected_particles.reshape(
                num_updates, self.particle_dim
            )  # [num_updates, dim]

            # Zero out the diagonal (score of staying at the current token).
            batch_idx = torch.arange(num_updates, device=self.device).unsqueeze(1).expand_as(particle_flat)
            site_idx = torch.arange(self.particle_dim, device=self.device).unsqueeze(0).expand_as(particle_flat)
            scores_flat[batch_idx, site_idx, particle_flat] = 0.0

            # Propose a joint (position, value) transition via categorical sampling.
            scores_2d = scores_flat.reshape(num_updates, -1)  # [num_updates, dim * vocab_size]
            transition_probs = scores_2d / scores_2d.sum(dim=1, keepdim=True)
            idx = torch.multinomial(transition_probs, num_samples=1).squeeze(1)  # [num_updates]
            revised_pos = idx // self.vocab_size    # [num_updates]
            revised_value = idx % self.vocab_size   # [num_updates]

            revised_particle_flat = particle_flat.clone()
            revised_particle_flat.scatter_(
                1, revised_pos.unsqueeze(1), revised_value.unsqueeze(1)
            )

            # Thinning: accept the proposed move with probability
            # outgoing_rate / beta_t.
            outgoing_rate = scores_2d.sum(dim=1)                    # [num_updates]
            beta_t = self.beta[current_interval[update_indices] + 1]
            accept_prob = (outgoing_rate / beta_t).clamp(max=1.0)
            accepted = torch.bernoulli(accept_prob).to(torch.long)  # [num_updates]

            ret_particle_flat = torch.where(
                accepted.bool().unsqueeze(-1),
                revised_particle_flat,
                particle_flat,
            )
            ret_particles[update_indices] = ret_particle_flat.view(
                num_updates, *self.particle_shape
            )

        return ret_particles

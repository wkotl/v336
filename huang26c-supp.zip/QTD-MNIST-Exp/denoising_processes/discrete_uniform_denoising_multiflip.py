"""Multi-flip variant of the discrete uniform denoising process.

Extends TruncatedUniformizationUniform with two new parameters:

- ``num_flips``:      Number of (position, value) transitions proposed per
                     accepted event.  The original process uses ``num_flips=1``.
                     Larger values allow the particle to move further in a single
                     iteration at the cost of less fine-grained control.

- ``poisson_factor``: Scalar multiplier applied to the Poisson rate before
                     sampling the number of jump events in each time interval.
                     Values > 1 increase the expected iteration count (finer
                     time resolution); values < 1 reduce it (coarser, faster).
"""

import torch
from tqdm import tqdm

from denoising_processes import DenoisingProcess, register_denoising_process


@register_denoising_process(name="discrete_uniform_multiflip")
class TruncatedUniformizationUniformMultiFlip(DenoisingProcess):
    """Truncated Uniformization with multi-bit flips and adjustable Poisson rate.

    Identical to :class:`TruncatedUniformizationUniform` except that each
    accepted jump proposes ``num_flips`` simultaneous (position, value)
    transitions sampled without replacement from the score distribution, and
    the Poisson event count in every interval is scaled by ``poisson_factor``.

    Args:
        batch_size:      Number of particles to generate in parallel.
        start_time:      Start time of the reverse process.
        mixing_time:     End time of the reverse process.
        particle_shape:  Shape of each particle, e.g. ``(H*W, num_bits)``.
        device:          Torch device.
        vocab_size:      Number of discrete states per dimension (2 for bits).
        discrete_scores: Callable ``(x, t) -> scores`` returning shape
                         ``[batch, *particle_shape, vocab_size]``.
        early_stopping:  Stop when remaining time drops below this threshold.
        num_flips:       Number of bits to flip per accepted event (default 1).
                         Must satisfy ``num_flips <= particle_dim * (vocab_size - 1)``.
        poisson_factor:  Multiply the Poisson mean by this factor (default 1.0).
                         >1 → more iterations (finer); <1 → fewer (coarser/faster).
    """

    def __init__(
        self,
        batch_size: int,
        start_time: float,
        mixing_time: float,
        particle_shape: tuple,
        device: torch.device,
        vocab_size: int,
        discrete_scores=None,
        early_stopping: float = 1e-3,
        num_flips: int = 1,
        poisson_factor: float = 1.0,
    ):
        super().__init__(batch_size, start_time, mixing_time, particle_shape, device)
        self.vocab_size      = vocab_size
        self.discrete_scores = discrete_scores
        self.early_stopping  = early_stopping
        self.num_flips       = num_flips
        self.poisson_factor  = poisson_factor

        self.particle_dim = int(
            torch.tensor(self.particle_shape, dtype=torch.float32).prod().item()
        )

        # Maximum meaningful num_flips: each dimension can only flip to
        # (vocab_size - 1) other values, so the diagonal-zeroed score matrix
        # has at most particle_dim * (vocab_size - 1) non-zero entries.
        max_flips = self.particle_dim * (self.vocab_size - 1)
        if self.num_flips > max_flips:
            raise ValueError(
                f"num_flips={num_flips} exceeds the maximum of {max_flips} "
                f"(particle_dim={self.particle_dim}, vocab_size={vocab_size})."
            )

        self.initial_sampler = lambda: torch.randint(
            0,
            self.vocab_size,
            (self.batch_size, *self.particle_shape),
            device=self.device,
        )

        # Build time-interval endpoints via geometric interpolation.
        t = self.start_time
        endpoints = []
        while True:
            endpoints.append(t)
            if t > self.mixing_time - self.early_stopping:
                break
            t = (2.0 / 3.0) * t + (1.0 / 3.0) * self.mixing_time
        self.time_endpoints = torch.tensor(
            endpoints, device=self.device, dtype=torch.float32
        )

        # Upper bound on the jump rate in each interval.
        denom     = self.vocab_size * (self.mixing_time - self.time_endpoints)
        self.beta = self.vocab_size * (self.particle_dim + self.particle_dim / denom)
        self.W    = len(self.time_endpoints) - 1

    def denoise(self) -> torch.Tensor:
        """Run the full reverse process and return generated particles.

        Returns:
            Integer tensor of shape ``[batch_size, *particle_shape]``.
        """
        ret_particles = self.initial_sampler()

        # Sample event counts per interval, scaled by poisson_factor.
        lambda_w     = self.beta[1:] * (self.time_endpoints[1:] - self.time_endpoints[:-1])
        poisson_mean = (
            lambda_w.unsqueeze(0).expand(self.batch_size, self.W)
            * self.poisson_factor
        )
        inner_iteration_num = torch.poisson(poisson_mean).to(torch.long)  # [batch, W]

        total_per_sample = inner_iteration_num.sum(dim=1)
        max_events       = int(total_per_sample.max().item())
        avg_iters        = float(total_per_sample.float().mean().item())
        print(
            f"  [TU-MultiFlip] num_flips={self.num_flips}  "
            f"poisson_factor={self.poisson_factor}  "
            f"Avg iterations: {avg_iters:.1f}  "
            f"(min={total_per_sample.min().item()}, max={max_events})"
        )

        # Pre-allocate event timestamp and interval buffers.
        sampled_timestamps = torch.empty(
            self.batch_size, max_events, device=self.device, dtype=torch.float32
        )
        sampled_interval = torch.empty(
            self.batch_size, max_events, device=self.device, dtype=torch.int32
        )

        for b in range(self.batch_size):
            offset = 0
            for w in range(self.W):
                n = inner_iteration_num[b, w].item()
                if n > 0:
                    low  = self.time_endpoints[w]
                    high = self.time_endpoints[w + 1]
                    s    = torch.rand(n, device=self.device) * (high - low) + low
                    sampled_timestamps[b, offset : offset + n] = s
                    sampled_interval[b, offset : offset + n]   = w
                offset += n
            sampled_timestamps[b, offset:] = self.mixing_time  # pad

        sampled_timestamps, _ = torch.sort(sampled_timestamps, dim=1)

        for n in tqdm(range(max_events), desc="Inference", unit="step"):
            current_timestamps = sampled_timestamps[:, n]   # [batch]
            current_interval   = sampled_interval[:, n]     # [batch]

            update_indices = (
                current_timestamps < self.mixing_time - self.early_stopping / 2.0
            ).nonzero(as_tuple=True)[0]
            num_updates = update_indices.size(0)
            if num_updates == 0:
                continue

            selected_particles  = ret_particles[update_indices]         # [U, *shape]
            mirrored_timestamps = self.mixing_time - current_timestamps[update_indices]

            current_scores = self.discrete_scores(
                selected_particles, mirrored_timestamps
            )  # [U, *particle_shape, vocab_size]

            scores_flat  = current_scores.reshape(num_updates, self.particle_dim, self.vocab_size)
            particle_flat = selected_particles.reshape(num_updates, self.particle_dim)

            # Zero out the diagonal (score of staying at the current token).
            batch_idx = (
                torch.arange(num_updates, device=self.device)
                .unsqueeze(1).expand_as(particle_flat)
            )
            site_idx = (
                torch.arange(self.particle_dim, device=self.device)
                .unsqueeze(0).expand_as(particle_flat)
            )
            scores_flat[batch_idx, site_idx, particle_flat] = 0.0

            # Flatten to [U, dim * vocab_size] for sampling.
            scores_2d     = scores_flat.reshape(num_updates, -1)           # [U, D*V]
            outgoing_rate = scores_2d.sum(dim=1)                           # [U]
            beta_t        = self.beta[current_interval[update_indices] + 1]
            accept_prob   = (outgoing_rate / beta_t).clamp(max=1.0)        # [U]

            transition_probs = scores_2d / outgoing_rate.clamp(min=1e-12).unsqueeze(1)

            # ── Algorithm 3, lines 9-11: num_flips independent micro-steps ────
            # Each micro-step independently draws a bit position from the
            # reference-state score distribution and accepts with prob accept_prob.
            # If the same position is drawn multiple times, it is flipped iff
            # ANY of its micro-steps was accepted (logical OR, not sequential toggle).
            all_idx = torch.multinomial(
                transition_probs, num_samples=self.num_flips, replacement=True
            )                                                               # [U, M]
            all_accepts = torch.bernoulli(
                accept_prob.unsqueeze(1).expand(-1, self.num_flips)
            ).bool()                                                        # [U, M]

            pos_all = all_idx // self.vocab_size                           # [U, M]

            # flip_needed[u, j] = True iff position j has >=1 accepted micro-step.
            flip_count = torch.zeros(
                num_updates, self.particle_dim, device=self.device
            )
            flip_count.scatter_add_(1, pos_all, all_accepts.float())
            flip_needed = flip_count > 0                                   # [U, D]

            # For binary vocab: flip = XOR 1 at needed positions.
            result = particle_flat ^ flip_needed.long()
            ret_particles[update_indices] = result.reshape(
                num_updates, *self.particle_shape
            )

        return ret_particles

"""Score network for mnist_small_tasks — UNet adapted for small (8×8 / 16×16) images."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import math
import torch
import torch.nn as nn
import diffusers


class MNISTSmallNet(nn.Module):
    """UNet score network for small-resolution MNIST discrete diffusion.

    Identical in design to MNISTFCNet but with block count and attention
    placement chosen to suit small images (8×8 or 16×16).  The number of
    UNet resolution levels is inferred from ``len(cfg.model.block_out_channels)``.

    For 16×16 images use 3 blocks (e.g. [32, 64, 128] or [128, 256, 512]).
    For  8×8 images use 2 blocks for a 4×4 bottleneck, or 3 blocks for a
    2×2 bottleneck with higher model capacity (e.g. [128, 256, 512]).
    """

    def __init__(self, cfg):
        super().__init__()
        num_out = int(math.log2(cfg.num_gray_levels))
        self.num_out = num_out

        model_cfg          = cfg.model
        block_out_channels = tuple(model_cfg.block_out_channels)
        layers_per_block   = model_cfg.layers_per_block
        time_embed_dim     = model_cfg.time_embed_dim
        use_attn           = model_cfg.get("use_attention", True)

        n_blocks = len(block_out_channels)
        down_block_types = tuple(
            "AttnDownBlock2D" if (use_attn and i == n_blocks - 2) else "DownBlock2D"
            for i in range(n_blocks)
        )
        up_block_types = tuple(
            "AttnUpBlock2D" if (use_attn and i == 1) else "UpBlock2D"
            for i in range(n_blocks)
        )

        self.unet = diffusers.UNet2DModel(
            sample_size        = cfg.image_size,
            in_channels        = 1,
            out_channels       = num_out * 2,
            layers_per_block   = layers_per_block,
            block_out_channels = block_out_channels,
            down_block_types   = down_block_types,
            up_block_types     = up_block_types,
            time_embedding_dim = time_embed_dim,
        )

    def forward(self, sample: torch.Tensor, timestep, return_dict: bool = True):
        """
        Args:
            sample:    [B, 1, H, W] float in [-1, 1]
            timestep:  [B] or scalar diffusion time (scaled to ~1000 range)
        Returns:
            log-scores [B, H, W, num_out, 2]
        """
        out = self.unet(sample, timestep, return_dict=return_dict)
        if return_dict:
            s = out.sample.permute(0, 2, 3, 1)
            s = s.view(*s.shape[:-1], self.num_out, 2)
            return type(out)(sample=s)
        else:
            s = out.permute(0, 2, 3, 1)
            s = s.view(*s.shape[:-1], self.num_out, 2)
            return s

"""Abstract base trainer — owns the training loop, optimizer, and checkpoint logic."""
from abc import ABC, abstractmethod
import os

import torch
import diffusers
import numpy as np
import matplotlib.pyplot as plt
from tqdm.auto import tqdm

from MNIST_generation_tasks.data import get_dataloader


class BaseTrainer(ABC):

    def __init__(self, cfg, device):
        self.cfg    = cfg
        self.device = device

    # ── Subclass contract ────────────────────────────────────────────────────

    @abstractmethod
    def build_model(self) -> torch.nn.Module:
        """Instantiate model, move to self.device, return it."""

    @abstractmethod
    def build_noise_scheduler(self):
        """Return the noise / noising-process object."""

    @abstractmethod
    def compute_loss(self, batch, model, noise_scheduler) -> torch.Tensor:
        """Forward pass for one batch. Return scalar differentiable loss."""

    # ── Shared training loop ─────────────────────────────────────────────────

    def run(self):
        cfg    = self.cfg
        device = self.device

        os.makedirs(cfg.output.results_dir,    exist_ok=True)
        os.makedirs(cfg.output.checkpoint_dir, exist_ok=True)

        _, dataloader   = get_dataloader(cfg)
        model           = self.build_model()
        noise_scheduler = self.build_noise_scheduler()

        optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.training.learning_rate)
        lr_sched  = diffusers.optimization.get_cosine_schedule_with_warmup(
            optimizer          = optimizer,
            num_warmup_steps   = cfg.training.lr_warmup_steps,
            num_training_steps = len(dataloader) * cfg.training.num_epochs,
        )

        loss_history = []
        for epoch in range(cfg.training.num_epochs):
            model.train()
            pbar = tqdm(total=len(dataloader), desc=f"Epoch {epoch}")
            for batch in dataloader:
                loss = self.compute_loss(batch, model, noise_scheduler)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                lr_sched.step()
                optimizer.zero_grad()
                loss_val = loss.item()
                loss_history.append(loss_val)
                pbar.update(1)
                pbar.set_postfix(loss=loss_val, lr=lr_sched.get_last_lr()[0])
            pbar.close()

        self._save(model, loss_history)

    # ── Shared save logic ────────────────────────────────────────────────────

    def _save(self, model, loss_history):
        cfg    = self.cfg
        prefix = os.path.splitext(cfg.output.get("model_name", "model.pt"))[0]

        ckpt_path = f"{cfg.output.checkpoint_dir}/{prefix}.pt"
        torch.save(model.state_dict(), ckpt_path)
        print(f"Saved model      → {ckpt_path}")

        arr      = np.array(loss_history)
        npy_path = f"{cfg.output.results_dir}/{prefix}_loss_history.npy"
        np.save(npy_path, arr)
        print(f"Saved loss       → {npy_path}")

        self._plot_loss(arr, prefix)

    def _plot_loss(self, arr, prefix, ema_weight=0.9):
        cfg = self.cfg

        def smooth(values):
            last, out = values[0], []
            for v in values:
                last = ema_weight * last + (1 - ema_weight) * v
                out.append(last)
            return np.array(out)

        plt.figure(figsize=(10, 6))
        plt.plot(arr, alpha=0.3, label="Raw")
        plt.plot(smooth(arr), linewidth=1.5, label="Smoothed (EMA)")
        plt.xlabel("Step")
        plt.ylabel("Loss")
        plt.title(f"Training Loss  [{cfg.model.type}]  "
                  f"{cfg.image_size}×{cfg.image_size}, {cfg.num_gray_levels} levels")
        plt.legend()
        plt.grid(True)
        path = f"{cfg.output.results_dir}/{prefix}_training_loss.png"
        plt.savefig(path, dpi=150)
        plt.close()
        print(f"Saved loss plot  → {path}")

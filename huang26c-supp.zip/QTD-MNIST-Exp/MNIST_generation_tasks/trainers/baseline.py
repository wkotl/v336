"""DDPM continuous-diffusion trainer (MSE noise prediction)."""
import torch
import torch.nn.functional as F
import diffusers

from MNIST_generation_tasks.trainers.base import BaseTrainer


def build_unet(cfg):
    """Shared UNet builder (used by trainer and sampler)."""
    n    = len(cfg.model.block_out_channels)
    ch   = tuple(cfg.model.block_out_channels)
    attn = cfg.model.get("use_attention", True)
    down = tuple("AttnDownBlock2D" if (attn and i == n - 2) else "DownBlock2D" for i in range(n))
    up   = tuple("AttnUpBlock2D"   if (attn and i == 1)     else "UpBlock2D"   for i in range(n))
    return diffusers.UNet2DModel(
        sample_size        = cfg.image_size,
        in_channels        = 1,
        out_channels       = 1,
        layers_per_block   = cfg.model.layers_per_block,
        block_out_channels = ch,
        down_block_types   = down,
        up_block_types     = up,
        time_embedding_dim = cfg.model.time_embed_dim,
    )


class BaselineTrainer(BaseTrainer):
    """Train a continuous DDPM model with MSE epsilon prediction."""

    def build_model(self):
        model = build_unet(self.cfg).to(self.device)
        print(f"Baseline model parameters: {sum(p.numel() for p in model.parameters()):,}")
        return model

    def build_noise_scheduler(self):
        return diffusers.DDPMScheduler(
            num_train_timesteps=self.cfg.noising.num_train_timesteps,
        )

    def compute_loss(self, batch, model, noise_scheduler):
        clean = batch["images"].to(self.device)          # [B, 1, H, W] float in [-1,1]
        B     = clean.shape[0]
        T     = self.cfg.noising.num_train_timesteps
        noise = torch.randn_like(clean)
        t     = torch.randint(0, T, (B,), device=self.device).long()
        noisy = noise_scheduler.add_noise(clean, noise, t)
        pred  = model(noisy, t).sample
        return F.mse_loss(pred, noise)

"""Discrete uniform-diffusion trainer (score-entropy loss)."""
import torch

from MNIST_generation_tasks.trainers.base import BaseTrainer
from MNIST_generation_tasks.networks.mnist_small_net import MNISTSmallNet


class DiscreteTrainer(BaseTrainer):
    """Train a bit-level discrete diffusion model with score-entropy loss."""

    def build_model(self):
        model = MNISTSmallNet(self.cfg).to(self.device)
        print(f"Discrete model parameters: {sum(p.numel() for p in model.parameters()):,}")
        return model

    def build_noise_scheduler(self):
        from noising_processes.discrete_uniform_noising import DiscreteUniformNoisingProcess
        return DiscreteUniformNoisingProcess(
            start_time  = self.cfg.noising.start_time,
            mixing_time = self.cfg.noising.mixing_time,
            vocab_size  = 2,
        )

    def compute_loss(self, batch, model, noise_scheduler):
        cfg     = self.cfg
        device  = self.device
        num_out = int(cfg.num_gray_levels).bit_length() - 1

        clean    = batch["images"].to(device)            # [B, 1, H, W] long
        B, _, H, W = clean.shape

        t = (
            torch.rand(B, device=device, dtype=torch.float32)
            * (noise_scheduler.mixing_time - noise_scheduler.start_time)
            + noise_scheduler.start_time
        )

        pixels     = clean.squeeze(1).reshape(B, H * W)
        shifts     = torch.arange(num_out, device=device, dtype=torch.long)
        clean_bits = ((pixels.unsqueeze(-1) >> shifts) & 1).float()   # [B, H*W, num_out]

        noisy_bits   = noise_scheduler.add_noise(clean_bits, t)
        powers       = 2 ** shifts
        noisy_images = (noisy_bits.round().long() * powers).sum(-1).reshape(B, 1, H, W)
        noisy_input  = (noisy_images.float() / (cfg.num_gray_levels - 1)) * 2.0 - 1.0

        noise_pred = model(noisy_input, t * cfg.model.time_scale)["sample"]
        return _score_entropy_loss(noise_pred, clean, noisy_images, t)


def _score_entropy_loss(noise_pred, clean_images, noisy_images, time):
    clean = clean_images.squeeze(1)    # [B, H, W]
    noisy = noisy_images.squeeze(1)

    C_out  = noise_pred.shape[-2]
    shifts = torch.arange(C_out, device=noisy.device, dtype=torch.long)
    bin_noisy = (noisy.unsqueeze(-1) >> shifts) & 1
    bin_clean = (clean.unsqueeze(-1) >> shifts) & 1

    log_score = noise_pred.gather(
        -1, (1 - bin_noisy).unsqueeze(-1).long()
    ).squeeze(-1)

    t          = time.float().view(-1, 1, 1, 1)
    exp_neg_2t = torch.exp(-2 * t)
    eps        = 1e-8
    val_diff   = (1 + exp_neg_2t) / (1 - exp_neg_2t + eps)
    val_same   = (1 - exp_neg_2t) / (1 + exp_neg_2t + eps)
    cdr        = torch.where(bin_noisy != bin_clean, val_diff, val_same)

    loss = torch.exp(log_score) - cdr * log_score
    return loss.sum() / loss.numel()

"""Unified FID evaluator — works with any BaseSampler subclass."""
import os

import torch
import torchvision
import datasets as hf_datasets
from tqdm.auto import tqdm
from torchmetrics.image.fid import FrechetInceptionDistance


# ── Image conversion helpers ─────────────────────────────────────────────────

def _to_inception(images_01, inception_size, device):
    """[N, 1, H, W] float in [0,1] → [N, 3, incep, incep] uint8."""
    imgs = torch.nn.functional.interpolate(
        images_01.to(device),
        size=(inception_size, inception_size),
        mode="bilinear",
        align_corners=False,
    )
    return (imgs.repeat(1, 3, 1, 1) * 255).to(torch.uint8)


def _quantize_01(images_01, cfg):
    """Quantize [N, 1, H, W] float in [0,1] to num_gray_levels discrete values.

    Applied to generated images so they go through the same pipeline as real
    images, keeping the FID comparison consistent.
    """
    num_levels = cfg.num_gray_levels
    thresholds = torch.linspace(
        -1.0 / (2.0 * (num_levels - 1)),
        1.0 + 1.0 / (2.0 * (num_levels - 1)),
        steps=num_levels + 1,
    ).to(dtype=images_01.dtype)
    bins = torch.bucketize(images_01.cpu(), thresholds, right=False) - 1
    return bins.clamp(0, num_levels - 1).float() / (num_levels - 1)


def _real_pil_to_01(pil_images, cfg):
    """Quantize real MNIST PIL images through the same pipeline used during training.

    Uses torchvision PIL Resize (matching data.py) for both baseline and discrete
    so that real image preprocessing is identical to training for a fair FID.
    """
    num_levels  = cfg.num_gray_levels
    image_size  = cfg.image_size
    output_size = cfg.output_image_size

    thresholds = torch.linspace(
        -1.0 / (2.0 * (num_levels - 1)),
        1.0 + 1.0 / (2.0 * (num_levels - 1)),
        steps=num_levels + 1,
    )
    resize    = torchvision.transforms.Resize((image_size, image_size))
    to_tensor = torchvision.transforms.ToTensor()

    out = []
    for img in pil_images:
        x = to_tensor(resize(img))                                  # [1, H, W] in [0,1]
        thr  = thresholds.to(dtype=x.dtype)
        bins = torch.bucketize(x, thr, right=False) - 1
        bins = bins.clamp(0, num_levels - 1).float() / (num_levels - 1)
        if output_size != image_size:
            bins = torch.nn.functional.interpolate(
                bins.unsqueeze(0), size=(output_size, output_size), mode="nearest"
            ).squeeze(0)
        out.append(bins)
    return torch.stack(out)                                        # [N, 1, H, W]


# ── Evaluator ────────────────────────────────────────────────────────────────

class FIDEvaluator:
    """Compute FID between real MNIST and generated images from any sampler."""

    def __init__(self, cfg, device, sampler):
        self.cfg     = cfg
        self.device  = device
        self.sampler = sampler

    def run(self):
        cfg    = self.cfg
        device = self.device
        os.makedirs(cfg.output.results_dir, exist_ok=True)

        fid            = FrechetInceptionDistance(feature=2048, normalize=False).to(device)
        num_samples    = cfg.fid.num_samples
        batch_size     = cfg.fid.batch_size
        inception_size = cfg.fid.inception_size

        # ── Real image features ───────────────────────────────────────────────
        print(f"Computing real image features ({num_samples} MNIST test images) …")
        mnist_test = hf_datasets.load_dataset("ylecun/mnist", split="test")
        mnist_test.reset_format()
        real_pil = [mnist_test[i]["image"] for i in range(min(num_samples, len(mnist_test)))]

        for start in tqdm(range(0, len(real_pil), batch_size), desc="Real images"):
            batch_pil = real_pil[start : start + batch_size]
            imgs_01   = _real_pil_to_01(batch_pil, cfg)
            fid.update(_to_inception(imgs_01, inception_size, device), real=True)

        # ── Generated image features + incremental FID ────────────────────────
        model         = self.sampler.build_model()
        prefix        = os.path.splitext(cfg.output.get("model_name", "model.pt"))[0]
        log_path      = f"{cfg.output.results_dir}/{prefix}_fid_score.txt"
        fid_history   = []
        num_generated = 0
        next_report   = cfg.fid.report_every

        with open(log_path, "w") as f:
            f.write(f"# FID log  model={cfg.model.type}  sampler={cfg.sampling.type}  "
                    f"num_gray_levels={cfg.num_gray_levels}\n"
                    "# num_generated\tFID\n")

        def _report(n):
            score = fid.compute().item()
            fid_history.append((n, score))
            print(f"  [FID @ {n:>6} samples]  {score:.4f}")
            with open(log_path, "a") as f:
                f.write(f"{n}\t{score:.4f}\n")

        print(f"Generating {num_samples} images …")
        with tqdm(total=num_samples, desc="Generated") as pbar:
            while num_generated < num_samples:
                this_n  = min(batch_size, num_samples - num_generated)
                imgs_01 = self.sampler.sample_batch(model, this_n)  # [N, 1, H, W] in [0,1]

                # quantize at image_size, then upscale — mirrors real image pipeline
                imgs_01 = _quantize_01(imgs_01, cfg)
                out_sz = cfg.output_image_size
                if out_sz != cfg.image_size:
                    imgs_01 = torch.nn.functional.interpolate(
                        imgs_01, size=(out_sz, out_sz), mode="nearest"
                    )
                fid.update(_to_inception(imgs_01, inception_size, device), real=False)

                num_generated += this_n
                pbar.update(this_n)

                while num_generated >= next_report:
                    _report(next_report)
                    next_report += cfg.fid.report_every

        if not fid_history or fid_history[-1][0] != num_generated:
            _report(num_generated)

        final = fid_history[-1][1]
        print(f"\n{'='*50}")
        print(f"  Final FID: {final:.4f}  ({num_generated} samples)")
        print(f"  Saved log → {log_path}")
        print(f"{'='*50}\n")

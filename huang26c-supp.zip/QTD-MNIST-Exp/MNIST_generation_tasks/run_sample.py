"""Unified sampling entry point.

Run from the repo root:

    # TU uniform (default)
    python -m MNIST_generation_tasks.run_sample

    # DDPM baseline
    python -m MNIST_generation_tasks.run_sample sampling.type=ddpm

    # TU multi-flip
    python -m MNIST_generation_tasks.run_sample sampling.type=tu_multiflip

Config:
    MNIST_generation_tasks/configs/mnist.yaml
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import random
import numpy as np
import torch
import hydra
from omegaconf import DictConfig

from MNIST_generation_tasks.samplers.baseline import BaselineSampler
from MNIST_generation_tasks.samplers.discrete import DiscreteSampler, MultiflipSampler

_SAMPLERS = {
    "ddpm":         BaselineSampler,
    "tu_uniform":   DiscreteSampler,
    "tu_multiflip": MultiflipSampler,
}


@hydra.main(version_base=None, config_path="configs", config_name="mnist")
def main(cfg: DictConfig):
    random.seed(cfg.seed)
    np.random.seed(cfg.seed)
    torch.manual_seed(cfg.seed)
    torch.cuda.manual_seed_all(cfg.seed)
    device = torch.device("cuda")
    print(f"Using device: {device} ({torch.cuda.get_device_name(0)})")

    stype = cfg.sampling.type
    if stype not in _SAMPLERS:
        raise ValueError(f"Unknown sampling.type '{stype}'. Choose from {list(_SAMPLERS)}")

    _SAMPLERS[stype](cfg, device).run()


if __name__ == "__main__":
    main()

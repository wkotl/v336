"""Abstract base sampler — owns image saving and upscaling."""
from abc import ABC, abstractmethod
import os

import torch
import torchvision


class BaseSampler(ABC):

    def __init__(self, cfg, device):
        self.cfg    = cfg
        self.device = device

    # ── Subclass contract ────────────────────────────────────────────────────

    @abstractmethod
    def build_model(self) -> torch.nn.Module:
        """Load model from checkpoint, set eval mode, return it."""

    @abstractmethod
    def sample_batch(self, model, n: int) -> torch.Tensor:
        """Generate n images. Return [N, 1, H, W] float in [0, 1]."""

    # ── Shared run / save logic ──────────────────────────────────────────────

    def run(self):
        cfg = self.cfg
        os.makedirs(cfg.output.results_dir, exist_ok=True)

        model = self.build_model()
        n     = cfg.sampling.batch_size
        print(f"Sampling {n} image(s) …")

        images = self.sample_batch(model, n)              # [N, 1, H, W] in [0,1]
        images = self._upscale(images)

        for i, img in enumerate(images):
            suffix = f"_{i}" if n > 1 else ""
            path   = f"{cfg.output.results_dir}/sample{suffix}.png"
            torchvision.transforms.ToPILImage()(img.cpu()).save(path)
            print(f"Saved → {path}")

    def _upscale(self, images):
        out_sz = self.cfg.output_image_size
        if out_sz != self.cfg.image_size:
            images = torch.nn.functional.interpolate(
                images, size=(out_sz, out_sz), mode="nearest"
            )
        return images

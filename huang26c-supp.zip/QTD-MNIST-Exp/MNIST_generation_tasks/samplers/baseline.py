"""DDPM reverse-diffusion sampler."""
import torch
import diffusers
from tqdm.auto import tqdm

from MNIST_generation_tasks.samplers.base import BaseSampler
from MNIST_generation_tasks.trainers.baseline import build_unet


class BaselineSampler(BaseSampler):

    def build_model(self):
        cfg  = self.cfg
        ckpt = f"{cfg.output.checkpoint_dir}/{cfg.output.get('model_name', 'model.pt')}"
        model = build_unet(cfg).to(self.device)
        model.load_state_dict(torch.load(ckpt, map_location=self.device, weights_only=True))
        model.eval()
        print(f"Loaded checkpoint from {ckpt}")
        return model

    def sample_batch(self, model, n):
        cfg    = self.cfg
        device = self.device
        H = W  = cfg.image_size

        scheduler = diffusers.DDPMScheduler(
            num_train_timesteps=cfg.noising.num_train_timesteps,
        )
        scheduler.set_timesteps(cfg.sampling.num_inference_steps, device=device)

        images = torch.randn(n, 1, H, W, device=device)
        with torch.no_grad():
            for t in tqdm(scheduler.timesteps, desc="Denoising"):
                pred   = model(images, t).sample
                images = scheduler.step(pred, t, images).prev_sample

        return (images.clamp(-1.0, 1.0) + 1.0) / 2.0    # [0, 1]

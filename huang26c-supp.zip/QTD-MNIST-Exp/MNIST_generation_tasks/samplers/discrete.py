"""Discrete diffusion samplers: TU uniform and TU multi-flip."""
import torch

from MNIST_generation_tasks.samplers.base import BaseSampler
from MNIST_generation_tasks.networks.mnist_small_net import MNISTSmallNet


class DiscreteSampler(BaseSampler):
    """TruncatedUniformization uniform sampler."""

    def build_model(self):
        cfg  = self.cfg
        ckpt = f"{cfg.output.checkpoint_dir}/{cfg.output.get('model_name', 'model.pt')}"
        model = MNISTSmallNet(cfg).to(self.device)
        model.load_state_dict(torch.load(ckpt, map_location=self.device, weights_only=True))
        model.eval()
        print(f"Loaded checkpoint from {ckpt}")
        return model

    def _discrete_scores(self, model, x_bits, t):
        """Interface between the TU denoiser and the score network."""
        cfg     = self.cfg
        device  = self.device
        num_out = int(cfg.num_gray_levels).bit_length() - 1
        B       = x_bits.shape[0]
        H = W   = cfg.image_size

        powers     = 2 ** torch.arange(num_out, device=device, dtype=torch.float32)
        pixel_vals = (x_bits.float() * powers).sum(dim=-1)
        input_img  = (pixel_vals / (cfg.num_gray_levels - 1)) * 2.0 - 1.0
        input_img  = input_img.view(B, 1, H, W)
        log_scores = model(input_img, t * cfg.model.time_scale)["sample"]
        return torch.exp(log_scores).reshape(B, H * W, num_out, 2)

    def _make_denoiser(self, model, batch_size):
        from denoising_processes.discrete_uniform_denoising import TruncatedUniformizationUniform
        cfg     = self.cfg
        num_out = int(cfg.num_gray_levels).bit_length() - 1

        @torch.no_grad()
        def discrete_scores(x_bits, t):
            return self._discrete_scores(model, x_bits, t)

        return TruncatedUniformizationUniform(
            batch_size      = batch_size,
            start_time      = cfg.noising.start_time,
            mixing_time     = cfg.noising.mixing_time,
            particle_shape  = (cfg.image_size * cfg.image_size, num_out),
            device          = self.device,
            vocab_size      = 2,
            discrete_scores = discrete_scores,
            early_stopping  = cfg.denoising.early_stopping,
        )

    def sample_batch(self, model, n):
        cfg     = self.cfg
        device  = self.device
        num_out = int(cfg.num_gray_levels).bit_length() - 1
        H = W   = cfg.image_size

        denoiser = self._make_denoiser(model, n)
        with torch.no_grad():
            samples = denoiser.denoise()                   # [N, H*W, num_out]

        shifts = torch.arange(num_out, device=device, dtype=torch.long)
        pixels = (samples.long() * (2 ** shifts)).sum(dim=-1)    # [N, H*W]
        images = pixels.view(n, 1, H, W).float() / (cfg.num_gray_levels - 1)
        return images                                       # [0, 1]


class MultiflipSampler(DiscreteSampler):
    """TruncatedUniformization multi-flip sampler — inherits score network from DiscreteSampler."""

    def _make_denoiser(self, model, batch_size):
        from denoising_processes.discrete_uniform_denoising_multiflip import (
            TruncatedUniformizationUniformMultiFlip,
        )
        cfg     = self.cfg
        num_out = int(cfg.num_gray_levels).bit_length() - 1

        @torch.no_grad()
        def discrete_scores(x_bits, t):
            return self._discrete_scores(model, x_bits, t)

        return TruncatedUniformizationUniformMultiFlip(
            batch_size      = batch_size,
            start_time      = cfg.noising.start_time,
            mixing_time     = cfg.noising.mixing_time,
            particle_shape  = (cfg.image_size * cfg.image_size, num_out),
            device          = self.device,
            vocab_size      = 2,
            discrete_scores = discrete_scores,
            early_stopping  = cfg.denoising.early_stopping,
            num_flips       = cfg.sampling.num_flips,
            poisson_factor  = cfg.sampling.poisson_factor,
        )

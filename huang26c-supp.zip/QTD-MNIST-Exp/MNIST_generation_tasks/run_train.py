"""Unified training entry point.

Run from the repo root:

    # Discrete diffusion (default)
    python -m MNIST_generation_tasks.run_train

    # DDPM baseline
    python -m MNIST_generation_tasks.run_train model.type=baseline

    # Override any config value inline
    python -m MNIST_generation_tasks.run_train model.type=discrete training.num_epochs=5

Config:
    MNIST_generation_tasks/configs/mnist.yaml
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import random
import numpy as np
import torch
import hydra
from omegaconf import DictConfig

from MNIST_generation_tasks.trainers.baseline import BaselineTrainer
from MNIST_generation_tasks.trainers.discrete import DiscreteTrainer

_TRAINERS = {
    "baseline": BaselineTrainer,
    "discrete": DiscreteTrainer,
}


@hydra.main(version_base=None, config_path="configs", config_name="mnist")
def main(cfg: DictConfig):
    random.seed(cfg.seed)
    np.random.seed(cfg.seed)
    torch.manual_seed(cfg.seed)
    torch.cuda.manual_seed_all(cfg.seed)
    device = torch.device("cuda")
    print(f"Using device: {device} ({torch.cuda.get_device_name(0)})")

    model_type = cfg.model.type
    if model_type not in _TRAINERS:
        raise ValueError(f"Unknown model.type '{model_type}'. Choose from {list(_TRAINERS)}")

    _TRAINERS[model_type](cfg, device).run()


if __name__ == "__main__":
    main()

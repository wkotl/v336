"""Shared MNIST data loading for baseline and discrete diffusion."""
import torch
import torchvision
import datasets as hf_datasets


def _make_thresholds(num_levels):
    return torch.linspace(
        -1.0 / (2.0 * (num_levels - 1)),
        1.0 + 1.0 / (2.0 * (num_levels - 1)),
        steps=num_levels + 1,
    )


def get_dataloader(cfg):
    """Load MNIST and return (dataset, dataloader).

    Quantizes to cfg.num_gray_levels bins, then:
      model.type == "baseline" → float images in [-1, 1]
      model.type == "discrete" → long images in {0, ..., num_gray_levels-1}
    """
    num_levels = cfg.num_gray_levels
    image_size = cfg.image_size
    model_type = cfg.model.type
    thresholds = _make_thresholds(num_levels)

    resize    = torchvision.transforms.Resize((image_size, image_size))
    to_tensor = torchvision.transforms.ToTensor()

    def transform(batch):
        images = []
        for img in batch["image"]:
            x    = to_tensor(resize(img))                          # [1, H, W] in [0,1]
            thr  = thresholds.to(dtype=x.dtype)
            bins = torch.bucketize(x, thr, right=False) - 1
            bins = bins.clamp(0, num_levels - 1)
            if model_type == "baseline":
                images.append((bins.float() / (num_levels - 1)) * 2.0 - 1.0)
            else:
                images.append(bins.long())
        return {"images": images}

    dataset = hf_datasets.load_dataset("ylecun/mnist", split="train")
    dataset.reset_format()
    dataset.set_transform(transform)

    dataloader = torch.utils.data.DataLoader(
        dataset,
        batch_size  = cfg.training.batch_size,
        shuffle     = True,
        num_workers = cfg.training.num_workers,
        pin_memory  = True,
    )
    return dataset, dataloader

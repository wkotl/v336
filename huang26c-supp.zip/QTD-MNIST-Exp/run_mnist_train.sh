#!/bin/bash
set -e

cd /workspace/Truncated_Uniformization

echo "========================================"
echo " Training DDPM baseline (mnist_base)"
echo "========================================"
python -m MNIST_generation_tasks.run_train --config-name mnist_base

echo ""
echo "========================================"
echo " Training QTD MultiFlip (mnist_qtd_mf)"
echo "========================================"
python -m MNIST_generation_tasks.run_train --config-name mnist_qtd_mf

echo ""
echo "========================================"
echo " FID evaluation: DDPM baseline"
echo "========================================"
python -m MNIST_generation_tasks.run_fid --config-name mnist_base

echo ""
echo "========================================"
echo " FID evaluation: QTD MultiFlip"
echo "========================================"
python -m MNIST_generation_tasks.run_fid --config-name mnist_qtd_mf

echo ""
echo "========================================"
echo " All runs complete."
echo "========================================"

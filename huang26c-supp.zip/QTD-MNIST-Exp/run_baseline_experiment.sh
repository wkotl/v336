#!/bin/bash
# =============================================================================
# Experiment 1: DDPM Baseline (mnist_baseline)
# Steps: train 5 seeds → combined loss plot → FID (10k) → 50 sample images
# =============================================================================
set -e

BASE="/workspace/Truncated_Uniformization/mnist_small_tasks"
SEEDS=(42 123 456 789 1024)
OUT_ROOT="$BASE/results_baseline"
CKPT_ROOT="$BASE/checkpoints_baseline"

# -----------------------------------------------------------------------------
# 1. Train each seed
# -----------------------------------------------------------------------------
echo "========================================"
echo " PHASE 1: Training (5 seeds)"
echo "========================================"

for SEED in "${SEEDS[@]}"; do
    echo ""
    echo "--- Training seed=$SEED ---"
    python -m mnist_small_tasks.mnist_baseline_train \
        seed=$SEED \
        "output.results_dir=$OUT_ROOT/seed_$SEED" \
        "output.checkpoint_dir=$CKPT_ROOT/seed_$SEED"
done

# -----------------------------------------------------------------------------
# 2. Combined loss plot
# -----------------------------------------------------------------------------
echo ""
echo "========================================"
echo " PHASE 2: Combined loss plot"
echo "========================================"

DIRS=()
SEED_LABELS=()
for SEED in "${SEEDS[@]}"; do
    DIRS+=("$OUT_ROOT/seed_$SEED")
    SEED_LABELS+=("$SEED")
done

python -m mnist_small_tasks.plot_loss_curves \
    --dirs  "${DIRS[@]}" \
    --seeds "${SEED_LABELS[@]}" \
    --title "MNIST Training Loss" \
    --output "$OUT_ROOT/combined_training_loss.png"

# -----------------------------------------------------------------------------
# 3. FID evaluation (10 000 samples each)
# -----------------------------------------------------------------------------
echo ""
echo "========================================"
echo " PHASE 3: FID evaluation (10k samples)"
echo "========================================"

for SEED in "${SEEDS[@]}"; do
    echo ""
    echo "--- FID seed=$SEED ---"
    python -m mnist_small_tasks.mnist_baseline_fid \
        seed=$SEED \
        "output.results_dir=$OUT_ROOT/seed_$SEED" \
        "output.checkpoint_dir=$CKPT_ROOT/seed_$SEED" \
        "fid.num_samples=10000"
done

# Summarise FID scores
echo ""
echo "--- FID summary ---"
for SEED in "${SEEDS[@]}"; do
    FID_FILE="$OUT_ROOT/seed_$SEED/baseline_fid_score.txt"
    if [ -f "$FID_FILE" ]; then
        LAST=$(grep -v "^#" "$FID_FILE" | tail -1 | awk '{print $2}')
        echo "  seed $SEED : FID = $LAST"
    fi
done

# -----------------------------------------------------------------------------
# 4. Generate 50 images per seed (case study)
# -----------------------------------------------------------------------------
echo ""
echo "========================================"
echo " PHASE 4: Sample 50 images (case study)"
echo "========================================"

for SEED in "${SEEDS[@]}"; do
    echo ""
    echo "--- Sampling seed=$SEED ---"
    python -m mnist_small_tasks.mnist_baseline_sample \
        seed=$SEED \
        "output.results_dir=$OUT_ROOT/seed_$SEED" \
        "output.checkpoint_dir=$CKPT_ROOT/seed_$SEED" \
        "sampling.batch_size=50"
done

echo ""
echo "========================================"
echo " Baseline experiment complete."
echo " Results: $OUT_ROOT"
echo "========================================"

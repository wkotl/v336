# Truncated Uniformization for MNIST Generation

This repository implements and compares two generative modelling approaches on
MNIST using a shared, modular codebase:

- **DDPM baseline** — standard continuous diffusion with MSE noise prediction
- **QTD-MultiFlip** — discrete bit-level diffusion via Quantized Truncated
  Uniformization (QTD) with multi-flip inference

Images are generated at 16×16 resolution with K=256 gray levels and upscaled
to 28×28 for evaluation.

---

## Repository layout

```
MNIST_generation_tasks/
├── configs/
│   ├── mnist_base.yaml        # DDPM baseline config
│   └── mnist_qtd_mf.yaml      # QTD-MultiFlip config
├── networks/
│   └── mnist_small_net.py     # UNet score network (shared by both models)
├── trainers/
│   ├── base.py                # Training loop, optimizer, checkpoint saving
│   ├── baseline.py            # DDPM trainer (MSE loss on discrete timesteps)
│   └── discrete.py            # QTD trainer (score-entropy loss, continuous t)
├── samplers/
│   ├── base.py                # Image saving and upscaling
│   ├── baseline.py            # DDPM reverse diffusion sampler
│   └── discrete.py            # TU-uniform and TU-multiflip samplers
├── data.py                    # MNIST dataloader with quantization
├── fid.py                     # Unified FID evaluator
├── run_train.py               # Training entry point
├── run_sample.py              # Sampling entry point
└── run_fid.py                 # FID evaluation entry point

denoising_processes/
├── discrete_uniform_denoising.py           # TU uniform sampler (single flip)
└── discrete_uniform_denoising_multiflip.py # TU multiflip sampler (Algorithm 3)

noising_processes/
└── discrete_uniform_noising.py             # Forward binary noising process
```

---

## Installation

```bash
pip install torch torchvision diffusers datasets torchmetrics[image] \
            hydra-core tqdm matplotlib numpy
```

---

## Models

### DDPM Baseline (`mnist_base.yaml`)

Standard DDPM trained on K=256 discrete gray levels.  The image is quantized
to K levels and normalised to `[-1, 1]`.  The model is trained with MSE
noise prediction on integer timesteps `t ∈ {0, …, T-1}`.

### QTD-MultiFlip (`mnist_qtd_mf.yaml`)

Discrete bit-level diffusion.  Each pixel value is encoded as
`log₂(K)=8` bits and the forward process independently corrupts each bit
toward Uniform({0,1}).  The reverse process runs via Truncated Uniformization
with multi-flip proposals (Algorithm 3): at each Poisson event, `M` candidate
bit-flip positions are sampled i.i.d. from the score distribution, each
independently accepted or rejected.  The set of accepted positions is toggled
exactly once (OR semantics — duplicate proposals do not cancel).

Training uses a score-entropy loss with continuous time `t ~ Uniform[0, 1]`.

---

## Usage

All commands are run from the **repository root**.  The `--config-name` flag
selects a config file from `MNIST_generation_tasks/configs/`.

### Training

```bash
# DDPM baseline
python -m MNIST_generation_tasks.run_train --config-name mnist_base

# QTD-MultiFlip
python -m MNIST_generation_tasks.run_train --config-name mnist_qtd_mf
```

Override any config value inline with Hydra syntax:

```bash
python -m MNIST_generation_tasks.run_train --config-name mnist_qtd_mf \
    training.num_epochs=20 output.model_name=my_model.pt
```

### Sampling

```bash
# DDPM baseline
python -m MNIST_generation_tasks.run_sample --config-name mnist_base

# QTD-MultiFlip
python -m MNIST_generation_tasks.run_sample --config-name mnist_qtd_mf \
    sampling.batch_size=4
```

Samples are saved to `output.results_dir` as `sample_0.png`, `sample_1.png`, …

### FID Evaluation

```bash
# DDPM baseline
python -m MNIST_generation_tasks.run_fid --config-name mnist_base

# QTD-MultiFlip
python -m MNIST_generation_tasks.run_fid --config-name mnist_qtd_mf
```

FID is computed against the MNIST test set using InceptionV3 (feature
dimension 2048).  Intermediate scores are logged every `fid.report_every`
samples to `results_dir/<model_name>_fid_score.txt`.

### Run everything sequentially

```bash
bash run_mnist_train.sh
```

Runs training then FID evaluation for both models in order.

---

## Configuration reference

Key fields shared by both configs:

| Field | Description |
|---|---|
| `seed` | Global random seed (Python, NumPy, PyTorch, CUDA) |
| `image_size` | Internal resolution for training/sampling (16) |
| `num_gray_levels` | Quantization levels K (256) |
| `output_image_size` | Upscaled output resolution (28) |
| `model.time_scale` | Multiplier mapping continuous t∈[0,1] to the UNet sinusoidal embedding range; **must be identical in training and inference** |
| `output.model_name` | Prefix for all output files (checkpoint, loss history, loss plot, FID log) |

DDPM-only fields (`mnist_base.yaml`):

| Field | Description |
|---|---|
| `noising.num_train_timesteps` | Number of discrete noise levels T |
| `sampling.num_inference_steps` | Reverse steps at inference (≤ T) |

QTD-only fields (`mnist_qtd_mf.yaml`):

| Field | Description |
|---|---|
| `noising.start_time` | Lower bound for t sampling during training (set > 0 to avoid score-entropy singularity at t=0) |
| `sampling.num_flips` | Flip candidates M per Poisson event |
| `sampling.poisson_factor` | Scales the Poisson event rate (< 1 → fewer events, faster; > 1 → more events, finer) |
| `denoising.early_stopping` | Stop the reverse process when remaining time < this threshold |

---

## Output files

After training and FID evaluation, the following files are written under
`output.results_dir` and `output.checkpoint_dir`:

```
checkpoints/
└── <model_name>.pt                     # model weights

results/
├── <model_name>_loss_history.npy       # per-step loss array
├── <model_name>_training_loss.png      # smoothed loss curve
└── <model_name>_fid_score.txt          # incremental FID log
```
